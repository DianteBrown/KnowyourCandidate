import Axios from './axios';
// import {_retrieveData} from '../asyncStorage/AsyncFuncs';

class WService{

static dashboard = (type) => {
	// const form = new FormData();
	// form.append('pageType',pageType);
	return new Promise((resolve,reject) => {
	resolve(Axios.get(type,{timeout : 7000}))})
}

static post = (type , form) => {
	return new Promise((resolve,reject) => {
		resolve(Axios.post(type,form,{timeout : 7000}))})
}

static dashboardPost = (type, header, form) => {
	return new Promise((resolve,reject) => {
		resolve(Axios.post(type,form,{headers : {
			'UUID' : header.id,
			'Authentication' : header.auth,
		},timeout : 7000}))})
}

static dashboardPut = (type, header, form) => {
	return new Promise((resolve,reject) => {
		resolve(Axios.put(type,form,{headers : {
			'UUID' : header.id,
			'Authentication' : header.auth,
		},timeout : 7000}))})
}

static get = (type,header) => {
	return new Promise((resolve,reject) => {
		resolve(Axios.get(type,{headers : {
			'UUID' : header.id,
			'Authentication' : header.auth,
		}}))})	
}

static addAlertDashboard = (plate_no , status , type) => {
	const form = new FormData();
	form.append('statusofvehicle',status);
	form.append('vehicle_plate_number',plate_no)
	return new Promise((resolve,reject) => {
		resolve(Axios.post(type,form,{timeout : 7000}))})
}



// static location = () => {
// 	console.log('location APi is called')
// 	return Axios.post('services.php?function=location').then(response =>{
// 		const list = [];
// 		response.data.data.locationList.map(i => {
// 			list.push({value : i.name}) 
// 		})
// 		// console.log(list);
// 		return list;
// 	})
// }


// static subLocation = (id) => {
// 	console.log('location APi is called')
// 	const form = new FormData();
// 	form.append('locationId',id);
// 	return Axios.post('services.php?function=sublocation', form).then(response =>{
// 		const list = [];
// 		response.data.data.sublocationList.map(i => {
// 			list.push({value : i.name}) 
// 		})
// 		// console.log(list);
// 		return list;
// 	})
// }


// static dropDown = (location,type) => {
// 	const form = new FormData();
// 	form.append('location',location);
// 	form.append('type',type);
// 	return Axios.post('services.php?function=dropdown',form).then(response =>{
// 		const list = [];
// 		response.data.data.sublocationList.map(i => {
// 			list.push({value : i.name}) 
// 		})
// 		// console.log(list);
// 		return list;
// 	})
// }

// static dropDown = (location,type) => {
// 	const form = new FormData();
// 	form.append('location',location);
// 	form.append('type',type);
// 	return Axios.post('services.php?function=dropdown',form).then(response =>{
// 		const list = [];
// 		response.data.data.sublocationList.map(i => {
// 			list.push({value : i.name}) 
// 		})
// 		// console.log(list);
// 		return list;
// 	})
// }

// static dropDownMultiList = (location,type) => {
// 	const form = new FormData();
// 	form.append('location',location);
// 	form.append('type',type);
// 	return Axios.post('services.php?function=dropdown',form).then(response =>{
// 		const list = [];
// 		response.data.data.sublocationList.map(i => {
// 			list.push(i.name) 
// 		})
// 		// console.log(list);
// 		return list;
// 	})
// }

// static dropDownInsight = (location,type) => {
// 	const form = new FormData();
// 	form.append('location',location);
// 	form.append('type',type);
// 	return Axios.post('services.php?function=dropdownInsightQuestions',form).then(response =>{
// 		const list = [];
// 		response.data.data.list.map(i => {
// 			list.push({value : i.name}) 
// 		})
// 		return list;
// 	})
// }

// static register = (registerStep,form) => {
// 	return Axios.post('services.php?function=register'+registerStep,form).then(response =>{
// 		return response;
// 	})
// }


// static auth = (name,form) => {
// 	return Axios.post('services.php?function='+name,form).then(response =>{
// 		return response;
// 	})
// }

// static dashboard = async (name,form) => {
// 	const userDetails = await _retrieveData('data')
// 	const headers = {
// 		'x-authorization': userDetails.token
// 	  }
// 	return Axios.post('services.php?function='+name,form,{
// 		headers : headers
// 	  }).then(response =>{
// 		return response;
// 	})
// }

// static addProducts = ( name,image ) => {
// 	return NetworkHelper.requestPost(WService.makeUrl("/products/add"), { name , image })
// }

// static getCategories = () => {
// 	return NetworkHelper.requestGet(WService.makeUrl("products/categories",))
// }

// static getSubCategories = (parentId) => {
// 	return NetworkHelper.requestGet(WService.makeUrl('products/categories', parentId))
// }

// static getCategoryById = (categoryId) => {
// 	return NetworkHelper.requestGet(WService.makeUrl("products/categories/" + categoryId))
// }

// static getAllProducts = (page, per_page) => {
// 	return NetworkHelper.requestGet(WService.makeUrl("products", "page=" + page + "&per_page=" + per_page))
// }

// static getProductsByCategory = (categoryId, page, per_page) => {
// 	return NetworkHelper.requestGet(WService.makeUrl("products", "page=" + page + "&per_page=" + per_page + "&category=" + categoryId))
// }

// static getRelatedProducts = (categoryId, productId, page, per_page) => {
// 	return NetworkHelper.requestGet(WService.makeUrl("products", "page=" + page + "&per_page=" + per_page + "&category=" + categoryId + "&exclude=[" + productId + "]"))
// }

// static searchProducts = (searchText, page, per_page, filter) => {
// 	let filterParams = ''
// 	if (filter) {
// 		if (filter.minValue) {
// 			filterParams += '&min_price=' + filter.minValue
// 		}
// 		if (filter.maxValue) {
// 			filterParams += '&max_price=' + filter.maxValue
// 		}
// 		if (filter.categoryId) {
// 			filterParams += '&category=' + filter.categoryId
// 		}
// 		if (filter.tagId) {
// 			filterParams += '&tag=' + filter.tagId
// 		}
// 	}
// 	const url = WService.makeUrl("products", "page=" + page + "&per_page=" + per_page + "&search=" + searchText + filterParams)
// 	return NetworkHelper.requestGet(url)
// }

// static getRecentProducts = (per_page) => {
// 	return NetworkHelper.requestGet(WService.makeUrl("products", "page=1&per_page=" + per_page))
// }


}
module.exports = WService
