import axios from 'axios';
const baseDomain = 'https://candidate-app-v1.herokuapp.com/';
// const baseDomain = 'http://10.0.11.149:9000/';

const baseURL = `${baseDomain}api/v1/`;
export default axios.create({
 baseURL,
 headers: { 'Access-Control-Allow-Origin': '*','Content-Type' : '', 'Cache-Control': 'no-cache', },
});