import React, { Component } from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import ApplicationStyles from '../../Themes/ApplicationStyles';
import colors from '../../Themes/Colors';
import { height, width } from 'react-native-dimension';
import images from '../../Themes/Images';

class Donate extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={[ApplicationStyles.mainContainer, { justifyContent: 'center' }]}>
                <View style={ApplicationStyles.compContainer}>
                    <Text style={ApplicationStyles.h5}>You are essential to making the change needed for this world to be a better place</Text>
                </View>
                <TouchableOpacity onPress={() => navigate('donatePayment')} style={[ApplicationStyles.buttonColord, { marginTop: height(10), marginBottom: height(2.5) }]}>
                    <Text style={ApplicationStyles.buttonText}>Donate</Text>
                </TouchableOpacity>
                <View style={{ alignItems: 'center' }}>
                    <Text onPress={() => navigate('Auth')} style={[ApplicationStyles.h6, { color: colors.appTextColor4 }]}>Skip</Text>
                </View>
                <View style={{ position: 'absolute', bottom: height(5), left: width(5) }}>
                    <Image source={images.jaguar_logo} resizeMode="contain" style={{ height: height(15), width: width(25) }} />
                </View>
            </View>
        );
    }
}

export default Donate;
