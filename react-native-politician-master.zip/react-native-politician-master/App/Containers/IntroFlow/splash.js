import React, { Component } from 'react';
import { View, Text, Image } from 'react-native';
import ApplicationStyles from '../../Themes/ApplicationStyles';
import colors from '../../Themes/Colors';
import images from '../../Themes/Images';
import { totalSize, height, width } from 'react-native-dimension';

class Splash extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }
    componentDidMount = () => setTimeout(() => {
        this.props.navigation.navigate('donate')
    }, 2000);
    render() {
        return (
            <View style={[ApplicationStyles.mainContainer, {}]}>
                <View style={[ApplicationStyles.compContainer, { marginTop: height(25) }]}>
                    <Text style={ApplicationStyles.h2}>Know</Text>
                    <Text style={ApplicationStyles.h2}>Your</Text>
                    <Text style={[ApplicationStyles.h1, { color: colors.appColor1 }]}>Candidate</Text>
                </View>
                <View style={{ position: 'absolute', bottom: height(5), left: width(5) }}>
                    <Image source={images.jaguar_logo} resizeMode="contain" style={{ height: height(15), width: width(25) }} />
                </View>
            </View>
        );
    }
}

export default Splash;
