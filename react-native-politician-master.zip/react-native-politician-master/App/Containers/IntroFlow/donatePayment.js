import React, { Component } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView } from 'react-native';
import ApplicationStyles from '../../Themes/ApplicationStyles';
import { height, width, totalSize } from 'react-native-dimension';
import colors from '../../Themes/Colors';
import images from '../../Themes/Images';

class DonatePayment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            card_numer: '1111 1111 1111 1111',
            cvc: '123',
            valid_thru: '09/24',
            name: 'Name Name'
        };
    }

    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={styles.card}>
                        <View style={[ApplicationStyles.compContainer, { alignItems: 'flex-end' }]}>
                            <Image source={images.visa_logo} resizeMode={"contain"} style={{ tintColor: '#FFFF', height: totalSize(5), width: totalSize(5) }} />
                        </View>
                        <View style={[ApplicationStyles.compContainer, { marginVertical: 0 }]}>
                            <Text style={[ApplicationStyles.h5, styles.cardText]}>{this.state.card_numer}</Text>
                        </View>
                        <View style={[ApplicationStyles.rowCompContainer, { marginVertical: height(5) }]}>
                            <Text style={[ApplicationStyles.h5, styles.cardText]}>{this.state.name}</Text>
                            <Text style={[ApplicationStyles.h5, styles.cardText]}>{this.state.valid_thru}</Text>
                        </View>
                    </View>
                    <TextInput
                        onChangeText={(value) => this.setState({ name: value })}
                        placeholder="Card holder name"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    <TextInput
                        onChangeText={(value) => this.setState({ card_numer: value })}
                        placeholder="Card number"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    <TextInput
                        onChangeText={(value) => this.setState({ valid_thru: value })}
                        placeholder="Valid thru"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    <TextInput
                        onChangeText={(value) => this.setState({ cvc: value })}
                        placeholder="CVC"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    <TextInput
                        placeholder="Amount $"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    <TouchableOpacity onPress={() => navigate('donate')} style={[ApplicationStyles.buttonColord, { marginVertical: height(10) }]}>
                        <Text style={ApplicationStyles.buttonText}>Donate</Text>
                    </TouchableOpacity>
                </ScrollView>
            </View>
        );
    }
}

export default DonatePayment;

const styles = StyleSheet.create({
    inputField: {
       // marginTop: height(1),
    },
    card: {
        marginHorizontal: width(7.5),
        backgroundColor: colors.appColor1,
        borderRadius: 10,
        marginVertical: height(2.5)
    },
    cardText: {
        color: '#FFFFFF'
    }
})