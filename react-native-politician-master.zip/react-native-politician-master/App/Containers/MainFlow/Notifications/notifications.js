import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';

class Notifications extends Component {
    constructor(props) {
        super(props);
        this.state = {
            notification: [
                { detail: 'You have been invited to BF-Squad, Tag the dots to send your answer', type: 'responsive' },
                { detail: 'This is an update from MEL', type: 'nonResponsive' },
                { detail: 'You have signed up for an event that is happening in less then 24 hours', type: 'responsive' },
                { detail: 'MaxShaw pinged you! Contact his in discord: Andrew435', type: 'nonResponsive' },
                { detail: 'The stream is live!', type: 'stream' },
            ]
        };
    }
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Notifications",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<Icon name="ios-search" type="ionicon" size={totalSize(2.5)} color={colors.appTextColor3} iconStyle={{ marginRight: width(5) }} />),
            headerLeft: (<HeaderMenuIcon />)
        }
    }
    render() {
        return (
            <View style={ApplicationStyles.mainContainer}>
                <FlatList
                    showsVerticalScrollIndicator={false}
                    data={this.state.notification}
                    renderItem={({ item }) =>
                        <View style={[ApplicationStyles.rowCompContainer, styles.notificationContainer]}>
                            <View style={{ flex: 1.5 }}>
                                <Image source={images.f1} style={{ height: totalSize(5), width: totalSize(5), borderRadius: 100 }} />
                            </View>
                            <View style={{ flex: 7.5 }}>
                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>Notification Title</Text>
                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight }]}>{item.detail}</Text>
                            </View>
                            <View style={{ flex: 1, alignItems: 'flex-end' }}>
                                <Icon name={"close"} type="material-community" size={totalSize(2)} color={colors.appTextColor4} />
                            </View>
                        </View>
                    }
                />
            </View>
        );
    }
}

export default Notifications;

const styles = StyleSheet.create({
    notificationContainer: {
        marginVertical: 0,
        marginTop: height(2.5),
    }
})