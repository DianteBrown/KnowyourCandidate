import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import FilterIcon from '../../../Components/FilterIcon';
import BillsList from '../../../Components/BillsList';
import ButtonGroup from '../../../Components/ButtonGroup';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';
class Bills extends Component {
    static contextType = Context
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            bills: [
                { title: 'Bill Title', image: images.bill, liked: false, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: true, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: true, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: false, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: true, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: true, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: false, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' },
                { title: 'Bill Title', image: images.bill, liked: false, bill_detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley' }
            ],
            buttons: ['New', 'Featured', 'Popular'],
            newBills : [],
            featuredBills : [],
            papularBills : [],
            selected : 'New'
        };
    }
    
    componentDidMount(){
        this.getData();
        this.props.navigation.addListener("didFocus", (payload) => {
            this.getData()
        })
    }

    getData(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }
            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.get('bills/new_bills',header).then(response => {
                this.setState({
                    newBills : response.data
                })
            })
            WService.get('bills/papular_bills',header).then(response => {
                console.log(response)
                this.setState({
                    papularBills : response.data
                })
            })
            WService.get('bills/featured_bills',header).then(response => {
                console.log(response)

                this.setState({
                    featuredBills : response.data
                })
            })
            }else{
                alert(this.context.state.languageWords.no_internet_connectivity)
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err.message)
        })
    }
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Bills",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filter')} />),
            headerLeft: (<HeaderMenuIcon />)
        }
    }
    onSelectType = (index) => {
        for (const item of this.state.bill_type) {
            item.selected = false
        }
        this.state.bill_type[index].selected = true
        this.setState({ loading: !this.state.loading })
    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ButtonGroup buttons={this.state.buttons} 
                selected={(val)=>{this.setState({
                    selected : val
                })}}
                />
                {this.screens()}
            </View>
        );
    }

    screens=()=>{
        const navigate = this.props.navigation.navigate

        if(this.state.selected == 'New'){
           return <BillsList bills={this.state.newBills}  navigate = {navigate}/>
        }
        else if(this.state.selected == 'Featured'){
            return <BillsList bills={this.state.featuredBills} navigate = {navigate} />
         }
         else if(this.state.selected == 'Popular'){
            return <BillsList bills={this.state.papularBills} navigate = {navigate} />
         }
    }
}

export default Bills;

const styles = StyleSheet.create({
    typeButtonOn: {
        backgroundColor: colors.appColor1,
        borderRadius: 25,
        elevation: 5,
    },
    typeButtonOff: {
        backgroundColor: colors.appTextColor5,
        borderRadius: 25,
        //  elevation: 5,
    },
    typeButtonText: {
        fontSize: totalSize(1),
        color: '#FFFFFF',
        marginHorizontal: 20,
        marginVertical: 2.5
    },
    feedContainer: {
        // height: height(20),
        //  borderRadius: 10,
        width: width(42.5),
        marginBottom: height(2.5)
    },
    feedImageStyle: {
        height: height(25),
        borderRadius: 5,
        width: null
        //width: width(42.5)
    }
})