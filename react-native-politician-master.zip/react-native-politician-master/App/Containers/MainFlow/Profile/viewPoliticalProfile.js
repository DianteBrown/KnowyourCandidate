import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import HeaderSearchIcon from '../../../Components/HeaderSearchIcon';
import Heading from '../../../Components/Heading';
import ReviewsList from '../../../Components/ReviewsList';
import HeadingUnderlined from '../../../Components/HeadingUnderlined';
import HeaderCloseIcon from '../../../Components/HeaderCloseIcon';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
let that = null
class ViewPoliticalProfile extends Component {
    componentDidMount = () => that = this
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Profile Detail",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<></>),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }
    constructor(props) {
        super(props);
        this.state = {
            isRatingModalVisible: false,
            isMenuModalVisible: false,
            isLanguageOptionsVisible: false,
            rated: false,
            photos: [
                // { image: images.p3 },
                // { image: images.p2 },
                // { image: images.p1 },
                // { image: images.p3 },
                // { image: images.p2 },
                // { image: images.p1 },
                // { image: images.p3 },
                // { image: images.p2 },
                // { image: images.p1 },
            ],
            dummy_detail: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
            rating: [],
            reviews: [
                // { name: 'Dustin Mcbride', image: images.u1, rating: 4, review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.' },
                // { name: 'Ken Perkins', image: images.u2, rating: 4.5, review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.' },
                // { name: 'Max Lee', image: images.u1, rating: 3.5, review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.' },
                // { name: 'Jackob Black', image: images.u2, rating: 5, review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.' }
            ],

        };
    }

    toggleRatingModal = () => this.setState({ isRatingModalVisible: !this.state.isRatingModalVisible })
    toggleMenuModal = () => this.setState({ isMenuModalVisible: !this.state.isMenuModalVisible })
    manageLanguageOptions = () => this.setState({ isLanguageOptionsVisible: !this.state.isLanguageOptionsVisible })
    onPostRating = () => { this.toggleRatingModal(); this.setState({ rated: true }) }
    onClickEditProfile = () => {
        this.toggleMenuModal()
        this.props.navigation.navigate('editPoliticalProfile')
    }
    onClickLogout = () => {
        this.toggleMenuModal()
        this.props.navigation.navigate('Auth')
    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={ApplicationStyles.mainContainer}>
                        <View style={{ marginHorizontal: width(5), flexDirection: 'row', marginVertical: height(2.5) }}>
                            <View style={{ flex: 4 }}>
                                <Image source={images.p1} style={{ height: height(35), width: null, borderRadius: 5 }} />
                            </View>
                            <View style={{ flex: 6 }}>
                                <View style={{ marginHorizontal: width(5) }}>
                                    <View style={{ flexDirection: 'row', alignItems: 'center', }}>
                                        <Text style={[ApplicationStyles.h4, styles.title]}>Frederick Simon</Text>
                                        <Icon name="ios-checkmark-circle" type="ionicon" size={totalSize(2.5)} color={colors.appColor1} iconStyle={{ marginHorizontal: 5 }} />
                                    </View>
                                    <View>
                                        <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>Political views</Text>
                                    </View>
                                    <View style={{ borderBottomWidth: 0.5, marginVertical: height(1), borderBottomColor: colors.steel }}></View>
                                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                            <Text style={[ApplicationStyles.h4, styles.title, { marginRight: 5 }]}>4.6</Text>
                                            <StarRating
                                                disabled={true}
                                                emptyStar={'ios-star-outline'}
                                                fullStar={'ios-star'}
                                                halfStar={'ios-star-half'}
                                                iconSet={'Ionicons'}
                                                maxStars={5}
                                                starStyle={{ marginRight: 2.5 }}
                                                starSize={totalSize(1.25)}
                                                rating={5}
                                                fullStarColor={colors.appColor1}
                                            />
                                        </View>
                                        {
                                            !this.state.rated ?
                                                <TouchableOpacity onPress={this.toggleRatingModal} style={{ backgroundColor: colors.appColor1, borderRadius: 100 }}>
                                                    <Text style={[ApplicationStyles.h6, { color: '#FFFF', fontSize: totalSize(1), marginHorizontal: 15, marginVertical: 2.5 }]}>Rate</Text>
                                                </TouchableOpacity>
                                                :
                                                <TouchableOpacity onPress={this.toggleRatingModal} style={{ backgroundColor: colors.appTextColor5, borderRadius: 100 }}>
                                                    <Text style={[ApplicationStyles.h6, { color: '#FFFF', fontSize: totalSize(1), marginHorizontal: 15, marginVertical: 2.5 }]}>Rated</Text>
                                                </TouchableOpacity>
                                        }
                                    </View>
                                    <View style={{ marginTop: height(1) }}>
                                        <Text style={[ApplicationStyles.h6, styles.heading]}>Education</Text>
                                        <Text style={[ApplicationStyles.h6, styles.topDetail]}>Yale University</Text>
                                    </View>
                                    <View style={{ marginTop: height(1) }}>
                                        <Text style={[ApplicationStyles.h6, styles.heading]}>Office</Text>
                                        <Text style={[ApplicationStyles.h6, styles.topDetail]}>House of Representative</Text>
                                    </View>
                                    <View style={{ marginTop: height(1) }}>
                                        <Text style={[ApplicationStyles.h6, styles.heading]}>Political background</Text>
                                        <Text style={[ApplicationStyles.h6, styles.topDetail]}>Lorem Ipsum is simply dummy text of the printing dummy text of the printing</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading="Photos" />
                            <Text onPress={() => navigate('gallery')} style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>View all</Text>
                        </View>
                        <View>
                            <FlatList
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                data={this.state.photos}
                                renderItem={({ item, index }) =>
                                    <Image source={item.image} style={[styles.photoStyle, { marginLeft: index === 0 ? width(5) : null }]} />
                                }
                            />
                        </View>

                        <HeadingUnderlined heading="Biography" />
                        <View style={[ApplicationStyles.compContainer]}>
                            <Text style={[ApplicationStyles.h5, styles.bottomDetail]}>{this.state.dummy_detail}</Text>
                        </View>

                        <HeadingUnderlined heading="Goals and Plans" />
                        <View style={[ApplicationStyles.compContainer]}>
                            <Text style={[ApplicationStyles.h5, styles.bottomDetail]}>{this.state.dummy_detail}</Text>
                        </View>

                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading={"Reviews (" + this.state.reviews.length + ")"} />
                            <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>View all</Text>
                        </View>
                        <View style={{ marginVertical: height(2.5) }}>
                            <ReviewsList data={this.state.reviews} />
                        </View>

                    </View>
                </ScrollView>
                <Modal visible={this.state.isRatingModalVisible} transparent animationType="slide">
                    <View style={{ flex: 1, justifyContent: 'center', backgroundColor: '#00000080' }}>
                        <View style={{ marginHorizontal: 0, backgroundColor: '#FFFF', borderRadius: 25 }}>
                            <View style={[ApplicationStyles.compContainer, {}]}>
                                <View>
                                    <Text style={[ApplicationStyles.h4, styles.title]}>Write your review</Text>
                                    <View style={styles.TitleUnderline}></View>
                                </View>
                            </View>
                            <View style={[ApplicationStyles.rowCompContainer, styles.ratingAreaContainer]}>
                                <View>
                                    <Text style={[ApplicationStyles.h5, styles.subTitle]}>Area 1</Text>
                                </View>
                                <View>
                                    <StarRating
                                        emptyStar={'ios-star'}
                                        fullStar={'ios-star'}
                                        halfStar={'ios-star-half'}
                                        iconSet={'Ionicons'}
                                        maxStars={5}
                                        starStyle={{ marginRight: 5 }}
                                        starSize={totalSize(2.5)}
                                        rating={4}
                                        emptyStarColor={colors.appTextColor5}
                                        fullStarColor={colors.appColor1}
                                    />
                                </View>
                            </View>
                            <View style={[ApplicationStyles.rowCompContainer, styles.ratingAreaContainer]}>
                                <View>
                                    <Text style={[ApplicationStyles.h5, styles.subTitle]}>Area 2</Text>
                                </View>
                                <View>
                                    <StarRating
                                        emptyStar={'ios-star'}
                                        fullStar={'ios-star'}
                                        halfStar={'ios-star-half'}
                                        iconSet={'Ionicons'}
                                        maxStars={5}
                                        starStyle={{ marginRight: 5 }}
                                        starSize={totalSize(2.5)}
                                        rating={3}
                                        emptyStarColor={colors.appTextColor5}
                                        fullStarColor={colors.appColor1}
                                    />
                                </View>
                            </View>
                            <View style={[ApplicationStyles.rowCompContainer, styles.ratingAreaContainer]}>
                                <View>
                                    <Text style={[ApplicationStyles.h5, styles.subTitle]}>Area 3</Text>
                                </View>
                                <View>
                                    <StarRating
                                        emptyStar={'ios-star'}
                                        fullStar={'ios-star'}
                                        halfStar={'ios-star-half'}
                                        iconSet={'Ionicons'}
                                        maxStars={5}
                                        starStyle={{ marginRight: 5 }}
                                        starSize={totalSize(2.5)}
                                        rating={5}
                                        emptyStarColor={colors.appTextColor5}
                                        fullStarColor={colors.appColor1}
                                    />
                                </View>
                            </View>
                            <TextInput
                                placeholder="Start typing your review here..."
                                multiline
                                scrollEnabled
                                style={{ marginHorizontal: width(5), textAlignVertical: 'top', height: height(20), fontSize: totalSize(1.5), fontFamily: family.appTextRegular }}
                            />
                            <View style={{ marginBottom: height(5) }}>
                                <TouchableOpacity onPress={() => this.onPostRating()} style={ApplicationStyles.buttonColord}>
                                    <Text style={ApplicationStyles.buttonText}>Post</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </Modal>
                <Modal
                    visible={this.state.isMenuModalVisible}
                    transparent
                    animationType="slide"
                >
                    <View style={{ flex: 1, backgroundColor: '#00000080' }}>
                        <View style={{ flex: 7, backgroundColor: '#FFFF', borderBottomRightRadius: 10, borderBottomLeftRadius: 10 }}>
                            <View style={[ApplicationStyles.rowCompContainer, { marginHorizontal: 0, marginVertical: height(5) }]}>
                                <HeaderMenuIcon onPress={this.toggleMenuModal} />
                                <Text style={ApplicationStyles.h5}>Menu</Text>
                                <HeaderCloseIcon onPress={this.toggleMenuModal} />
                            </View>
                            {
                                !this.state.isLanguageOptionsVisible ?
                                    <View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.onClickEditProfile} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>Edit Profile</Text>
                                        </View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.manageLanguageOptions} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>Change language</Text>
                                        </View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.onClickLogout} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, color: colors.appColor1 }]}>Log Out</Text>
                                        </View>
                                    </View>
                                    :
                                    <View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.manageLanguageOptions} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, color: colors.appColor1 }]}>Eng</Text>
                                        </View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.manageLanguageOptions} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, }]}>RU</Text>
                                        </View>
                                    </View>
                            }
                        </View>
                        <View style={{ flex: 3 }}>

                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
}

export default ViewPoliticalProfile;

const styles = StyleSheet.create({
    title: {
        fontSize: totalSize(1.75)
    },
    subTitle: {
        fontFamily: family.appTextMedium
    },
    heading: {
        fontFamily: family.appTextBold
    },
    topDetail: {
        fontFamily: family.appTextLight
    },
    photoStyle: {
        height: totalSize(10),
        width: totalSize(10),
        borderRadius: 5,
        marginVertical: height(2.5),
        marginRight: width(2.5)
    },
    TitleUnderline: {
        width: width(40),
        borderBottomWidth: 0.5,
        borderBottomColor: colors.appTextColor6,
        marginTop: 2.5
    },
    bottomDetail: {
        fontFamily: family.appTextLight
    },
    reviewContainer: {
        marginHorizontal: width(5),
        backgroundColor: '#FFFF',
        borderRadius: 5,
        elevation: 5,
        marginVertical: height(1),
        //flexDirection: 'row',
        //alignItems: 'center'
    },
    ratingAreaContainer: {
        marginTop: 0
    }
})