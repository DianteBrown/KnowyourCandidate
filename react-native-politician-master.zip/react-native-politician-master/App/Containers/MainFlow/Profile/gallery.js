import React, { Component } from 'react';
import { View, Text, Image, ScrollView } from 'react-native';
import images from '../../../Themes/Images';
import HeaderSearchIcon from '../../../Components/HeaderSearchIcon';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { width, height } from 'react-native-dimension';

class Gallery extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Gallery",

            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<HeaderSearchIcon />),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }

    constructor(props) {
        super(props);
        this.state = {
            photos: [
                { image: images.u2 },
                { image: images.u1 },
                { image: images.u2 },
                { image: images.u1 },
                { image: images.u2 },
                { image: images.u1 },
                { image: images.u2 },
                { image: images.u1 },
            ],
        };
    }

    render() {
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ScrollView>
                    <View style={{ marginHorizontal: width(5), flexWrap: 'wrap', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        {
                            this.state.photos.map((item, key) => {
                                return (
                                    <Image source={item.image} style={{ height: height(20), width: width(42.5), borderRadius: 10, marginBottom: height(2.5) }} />
                                )
                            })
                        }
                    </View>
                </ScrollView>
            </View>
        );
    }
}

export default Gallery;
