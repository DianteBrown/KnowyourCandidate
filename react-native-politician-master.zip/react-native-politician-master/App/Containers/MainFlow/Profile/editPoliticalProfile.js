import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import HeaderSearchIcon from '../../../Components/HeaderSearchIcon';
import Heading from '../../../Components/Heading';
import ReviewsList from '../../../Components/ReviewsList';
import HeadingUnderlined from '../../../Components/HeadingUnderlined';
import HeaderCloseIcon from '../../../Components/HeaderCloseIcon';
import ImageIcon from '../../../Components/ImageIcon';
import EditIcon from '../../../Components/EditIcon';
import ButtonColored from '../../../Components/ButtonColored';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import ImagePicker from 'react-native-image-picker';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';

const options = {
    title: "Select Photo",
  
    takePhotoButtonTitle: "Take Photo…",
    chooseFromLibraryButtonTitle: "Choose from Gallery"
  };
let that = null
class EditPoliticalProfile extends Component {
    static contextType = Context;
    componentDidMount = () => that = this
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Edit Profile",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<HeaderSearchIcon />),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }
    constructor(props) {
        super(props);
        this.state = {
            isRatingModalVisible: false,
            isMenuModalVisible: false,
            rated: false,
            photos: this.props.navigation.state.params.photos,
            user_name : this.props.navigation.state.params.user.user_name,
            full_name : this.props.navigation.state.params.user.full_name,
            political_background : this.props.navigation.state.params.user.political_background,
            biography : this.props.navigation.state.params.user.biography,
            Goals_and_plans : this.props.navigation.state.params.user.goals_and_plans,
            profile_photo : {uri : this.props.navigation.state.params.user.profile_photo},
            dummy_detail: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
            rating: [],
            reviews: [],
            education : '',
            review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.'
        };
    }

    Update(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }

        const form = new FormData();
        var length = false;
        this.state.photos.map((i,index)=>{
            if(typeof i == 'string'){
            }else{
                length = true
                form.append(`photos[${index}]`,i)
            }
        })

        const user_data = new FormData();
        user_data.append('email',this.context.state.user.email)
        user_data.append('full_name',this.state.full_name)
        user_data.append('user_name',this.state.user_name)
        user_data.append('education',this.state.education)
        user_data.append('biography',this.state.biography)
        user_data.append('goals_and_plans',this.state.Goals_and_plans)
        user_data.append('political_background',this.state.political_background)
        if(this.state.profile_photo.uri != this.props.navigation.state.params.user.profile_photo){
            user_data.append('profile_photo',this.state.profile_photo)

        }

        // form.append('role','Politician')
        // form.append('email',this.context.state.user.email)
        // form.append('email',this.context.state.user.email)
        // form.append('email',this.context.state.user.email)
        // form.append('email',this.context.state.user.email)
        

        

            NetInfo.fetch().then(async state => {
            this.setState({loader : true})
            if(state.isConnected){
            if(length)
            await WService.dashboardPost('users/add_photos',header,form).then(response => {
                // this.setState({
                //     comments : [...this.state.comments,response.data.text]
                // })
                // this.state.comments.push(response.data.text)
                // this.props.navigation.goBack()
                alert('succesfully updated photos');
                // this.getComments()

            })
            
            await WService.dashboardPost('users/update_account',header,user_data).then(response => {
                // this.setState({
                //     comments : [...this.state.comments,response.data.text]
                // })
                console.log(response.data);
                
                // this.state.comments.push(response.data.text)
                this.props.navigation.goBack()
                alert('succesfully updated photos');
                // this.getComments()

            })
            }else{
                alert('error')
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })
    
    }

    profilePhoto = () => {
        ImagePicker.showImagePicker(options, response => {
            if (response.didCancel) {
              console.log("User cancelled image picker");
            } else if (response.error) {
              console.log("ImagePicker Error: ", response.error);
            } else if (response.customButton) {
              console.log("User tapped custom button: ", response.customButton);
            } else {
                this.setState({ profile_photo: response });
                this.state.profile_photo['name'] = response.fileName;
                this.state.profile_photo['size'] = response.fileSize;
  
            }
          });
    }

    openGallery = () => {
        ImagePicker.showImagePicker(options, response => {
          if (response.didCancel) {
            console.log("User cancelled image picker");
          } else if (response.error) {
            console.log("ImagePicker Error: ", response.error);
          } else if (response.customButton) {
            console.log("User tapped custom button: ", response.customButton);
          } else {
            const photo = response;
            photo['name'] = response.fileName;
            photo['size'] = response.fileSize;
            const photosAll = this.state.photos;
            photosAll.push(photo)
            this.setState({
                photos : photosAll
            })

          }
        });
      };


    toggleRatingModal = () => this.setState({ isRatingModalVisible: !this.state.isRatingModalVisible })
    toggleMenuModal = () => this.setState({ isMenuModalVisible: !this.state.isMenuModalVisible })
    onPostRating = () => { this.toggleRatingModal(); this.setState({ rated: true }) }
    render() {
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={ApplicationStyles.mainContainer}>
                        <View style={{ marginHorizontal: width(5), flexDirection: 'row', marginVertical: height(2.5) }}>
                            <View style={{ flex: 4 }}>
                                <Image source={{uri : this.state.profile_photo.uri}} style={{ height: height(35), width: null, borderRadius: 5 }} />
                                <TouchableOpacity onPress={()=>{this.profilePhoto()}} style={{ borderRadius: 5, position: 'absolute', top: 0, bottom: 0, right: 0, left: 0, backgroundColor: '#00000080', alignItems: 'center', justifyContent: 'center' }}>
                                    <ImageIcon />
                                </TouchableOpacity>
                            </View>
                            <View style={{ flex: 6 }}>
                                <View style={{ marginLeft: width(5) }}>
                                    <View style={styles.EditItemContainer}>
                                        <TextInput 
                                        value={this.state.full_name}
                                        onChangeText={(val)=>{
                                            this.setState({
                                                full_name : val
                                            })
                                        }}
                                        style={[ApplicationStyles.h4, styles.title,{flex :1}]}></TextInput>
                                        <EditIcon />
                                    </View>
                                    <View style={styles.EditItemContainer}>
                                        <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>Political views</Text>
                                        <EditIcon />
                                    </View>
                                    <View style={{ borderBottomWidth: 0.5, marginVertical: height(1), borderBottomColor: colors.steel }}></View>
                                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                            <Text style={[ApplicationStyles.h4, styles.title, { marginRight: 5 }]}>4.6</Text>
                                            <StarRating
                                                disabled={true}
                                                emptyStar={'ios-star-outline'}
                                                fullStar={'ios-star'}
                                                halfStar={'ios-star-half'}
                                                iconSet={'Ionicons'}
                                                maxStars={5}
                                                starStyle={{ marginRight: 2.5 }}
                                                starSize={totalSize(1.25)}
                                                rating={5}
                                                fullStarColor={colors.appColor1}
                                            />
                                        </View>
                                    </View>
                                    <View style={{ marginTop: height(1) }}>
                                        <View style={styles.EditItemContainer}>
                                            <Text style={[ApplicationStyles.h6, styles.heading]}>Education</Text>
                                            <EditIcon />
                                        </View>
                                        <TextInput 
                                        value={this.state.education}
                                        onChangeText={(val)=>{
                                            this.setState({
                                                education : val
                                            })
                                        }}
                                        style={[ApplicationStyles.h6, styles.topDetail,{flex :1}]}></TextInput>                                    
                                        </View>
                                    <View style={{ marginTop: height(1) }}>
                                        <View style={styles.EditItemContainer}>
                                            <Text style={[ApplicationStyles.h6, styles.heading]}>Office</Text>
                                            <EditIcon />
                                        </View>
                                        <Text style={[ApplicationStyles.h6, styles.topDetail]}>House of Representative</Text>
                                    </View>
                                    <View style={{ marginTop: height(1) }}>
                                        <View style={styles.EditItemContainer}>
                                            <Text style={[ApplicationStyles.h6, styles.heading]}>Political background</Text>
                                            <EditIcon />
                                        </View>
                                        <TextInput 
                                        value={this.state.political_background}
                                        onChangeText={(val)=>{
                                            this.setState({
                                                political_background : val
                                            })
                                        }}
                                        style={[ApplicationStyles.h6, styles.topDetail,{flex :1}]}></TextInput>
                                                                            </View>
                                </View>
                            </View>
                        </View>
                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading="Photos" />
                            <TouchableOpacity onPress={()=>{this.openGallery()}}>
                            <Text style={[ApplicationStyles.h6, { color: colors.appColor1 }]}>Add Photo</Text>
                            </TouchableOpacity>
                        </View>
                        <View>
                            <FlatList
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                data={this.state.photos}
                                renderItem={({ item, index }) =>
                                    <Image source={item.uri != undefined ? {uri : item.uri} : {uri : item}} style={[styles.photoStyle, { marginLeft: index === 0 ? width(5) : null }]} />
                                }
                            />
                        </View>

                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading="Biography" />
                            <EditIcon />
                        </View>
                        <View style={[ApplicationStyles.compContainer]}>
                        <TextInput 
                                        value={this.state.biography}
                                        onChangeText={(val)=>{
                                            this.setState({
                                                biography : val
                                            })
                                        }}
                                        multiline={true}
                                        numberOfLines={5}
                                        textAlignVertical = 'top'
                                        style={[ApplicationStyles.h5, styles.bottomDetail,{flex :1}]}></TextInput>
                                                                </View>

                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading="Goals and Plans" />
                            <EditIcon />
                        </View>
                        <View style={[ApplicationStyles.compContainer]}>
                        <TextInput 
                                        value={this.state.Goals_and_plans}
                                        onChangeText={(val)=>{
                                            this.setState({
                                                Goals_and_plans : val
                                            })
                                        }}
                                        multiline={true}
                                        numberOfLines={5}
                                        textAlignVertical = 'top'
                                        style={[ApplicationStyles.h5, styles.bottomDetail,{flex :1}]}></TextInput>                        
                                        </View>
                        <View style={{ marginVertical: height(5) }}>
                            <ButtonColored onPress={() => {this.Update()}} buttonText="Done" />
                        </View>
                    </View>
                </ScrollView>
                <Modal
                    visible={this.state.isMenuModalVisible}
                    transparent
                    animationType="slide"
                >
                    <View style={{ flex: 1, backgroundColor: '#00000080' }}>
                        <View style={{ flex: 7, backgroundColor: '#FFFF', borderBottomRightRadius: 10, borderBottomLeftRadius: 10 }}>
                            <View style={[ApplicationStyles.rowCompContainer, { marginHorizontal: 0, marginVertical: height(5) }]}>
                                <HeaderMenuIcon onPress={this.toggleMenuModal} />
                                <Text style={ApplicationStyles.h5}>Menu</Text>
                                <HeaderCloseIcon onPress={this.toggleMenuModal} />
                            </View>
                            <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                <Text onPress={this.onClickEditProfile} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>Edit Profile</Text>
                            </View>
                            <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                <Text style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>Change language</Text>
                            </View>
                            <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                <Text style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, color: colors.appColor1 }]}>Log Out</Text>
                            </View>
                        </View>
                        <View style={{ flex: 3 }}>

                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
}

export default EditPoliticalProfile;

const styles = StyleSheet.create({
    title: {
        fontSize: totalSize(1.75)
    },
    subTitle: {
        fontFamily: family.appTextMedium
    },
    heading: {
        fontFamily: family.appTextBold
    },
    topDetail: {
        fontFamily: family.appTextLight
    },
    photoStyle: {
        height: totalSize(10),
        width: totalSize(10),
        borderRadius: 5,
        marginVertical: height(2.5),
        marginRight: width(2.5)
    },
    TitleUnderline: {
        width: width(40),
        borderBottomWidth: 0.5,
        borderBottomColor: colors.appTextColor6,
        marginTop: 2.5
    },
    bottomDetail: {
        fontFamily: family.appTextLight
    },
    reviewContainer: {
        marginHorizontal: width(5),
        backgroundColor: '#FFFF',
        borderRadius: 5,
        elevation: 5,
        marginVertical: height(1),
        //flexDirection: 'row',
        //alignItems: 'center'
    },
    ratingAreaContainer: {
        marginTop: 0
    },
    EditItemContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    }
})


