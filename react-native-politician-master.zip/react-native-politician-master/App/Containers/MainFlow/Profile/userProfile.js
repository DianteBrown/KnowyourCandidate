import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import ReviewsList from '../../../Components/ReviewsList';
import Heading from '../../../Components/Heading';
import ProfileFeedsList from '../../../Components/ProfileFeedsList';
import HeaderSearchIcon from '../../../Components/HeaderSearchIcon';
import ProfileCommentsList from '../../../Components/ProfileCommentsList';
import HeaderCloseIcon from '../../../Components/HeaderCloseIcon';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';
let that = null
class UserProfile extends Component {
    static contextType = Context;
    componentDidMount = () => {that = this; 
        this.props.navigation.addListener("didFocus", (payload) => {
            this.Users()
        }); }    
        static navigationOptions = ({ navigation }) => {
        return {
            title: "User Profile",

            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<HeaderSearchIcon />),
            headerLeft: (<HeaderMenuIcon onPress={() => that.toggleMenuModal()} />)
        }
    }
    constructor(props) {
        super(props);
        this.state = {
            isMenuModalVisible: false,
            isLanguageOptionsVisible: false,
            rated: false,
            photos: [],
            dummy_detail: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
            rating: [],
            reviews : {
                Count : 0,
                Ratings : []
            },
            feeds: [
                ],
            your_comments: [
                {
                    image: images.f2,
                    title: 'News Title',
                    date: '10.10.19',
                    detail: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.',
                    comments: [
                        { name: 'Dustin Mcbride', image: images.u1, review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.' },
                        { name: 'Ken Perkins', image: images.u2, review: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the.' },

                    ]
                }
            ],
            users : {
                profile_photo : ''
            }
        };
    }


    Users(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }
        NetInfo.fetch().then(async state => {
        this.setState({loader : true})
        if(state.isConnected){
        await WService.get('users/get_user?user_id='+this.context.state.user.user_id,header).then(response => {
            console.warn(response)
            this.setState({
                users : response.data
            })
        })
        await WService.get('users/get_photos?user_id='+this.context.state.user.user_id,header).then(response => {
            console.warn(response)
            this.setState({
                photos : response.data.Images
            })
        })
        console.log('hbjhb')
        await WService.get('users/get_reviews?user_id='+this.context.state.user.user_id,header).then(response => {
            console.warn('jhvjhv',response)
            if(response.data.Count == null)
            response.data.Count = 0;

            this.setState({
                reviews : response.data
            })
        })
        await WService.get('users/favourite_news?user_id='+this.context.state.user.user_id,header).then(response => {
            console.warn('ajhbsdjh feeds',response.data)
            this.setState({
                feeds : response.data
            })
        })
        }else{
            this.setState({loader : false})
        }

    }).catch(err => {
        alert(err)
    })

    }
    toggleMenuModal = () => this.setState({ isMenuModalVisible: !this.state.isMenuModalVisible })
    manageLanguageOptions = () => this.setState({ isLanguageOptionsVisible: !this.state.isLanguageOptionsVisible })

    onClickEditProfile = () => {
        this.toggleMenuModal();
        this.props.navigation.navigate('editUserProfile',{photos : this.state.photos,user : this.state.users})
    }
    onClickLogout = () => {
        this.toggleMenuModal()
        this.props.navigation.navigate('Auth')
    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={ApplicationStyles.mainContainer}>
                        <View style={{ marginHorizontal: width(5), flexDirection: 'row', marginVertical: height(2.5) }}>
                            <View style={{ flex: 4 }}>
                            <Image source={this.state.users.profile_photo != undefined && this.state.users.profile_photo != null && this.state.users.profile_photo != "" ? {uri : this.state.users.profile_photo} : images.u1} style={{ height: height(35), width: null, borderRadius: 5 }} />
                            </View>
                            <View style={{ flex: 6 }}>
                                <View style={{ marginHorizontal: width(5) }}>
                                    <View style={{}}>
                                    <Text style={[ApplicationStyles.h4, styles.title]}>{this.state.users.full_name}</Text>
        <Text style={[ApplicationStyles.h6, { color: colors.heading }]}>user view</Text>
                                    </View>
                                    <View style={{ borderBottomWidth: 0.5, marginVertical: height(1), borderBottomColor: colors.steel }}></View>
                                    <View style={{ marginTop: height(1) }}>
                                        <Text style={[ApplicationStyles.h6, styles.heading]}>Voter identity</Text>
                                        {/* <Text style={[ApplicationStyles.h6, styles.topDetail]}>Lorem Ipsum is simply dummy text of the printing dummy text of the printing</Text> */}
                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading='Photos' />
                            <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>View all</Text>
                        </View>
                        <View>
                            <FlatList
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                data={this.state.photos}
                                renderItem={({ item, index }) =>
                                <Image source={item.uri != undefined && item.uri != null ? {uri : item.uri} : {uri : item}} style={[styles.photoStyle, { marginLeft: index === 0 ? width(5) : null }]} />
                            }
                            />
                        </View>

                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading='Favorite news' />
                            <Text onPress={() => navigate('favoriteFeeds')} style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>View all</Text>
                        </View>
                        <View style={{ marginVertical: height(2.5) }}>
                            <ProfileFeedsList data={this.state.feeds} />
                        </View>

                        {/* <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                            <Heading heading='Your Comments(10)' />
                            <Text onPress={() => navigate('yourComments')} style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>View all</Text>
                        </View>
                        <View style={{ marginVertical: height(2.5) }}>
                            <ProfileCommentsList data={this.state.your_comments} />
                        </View> */}

                        <View style={[ApplicationStyles.rowCompContainer, { marginBottom: 0 }]}>
                        <Heading heading={`Reviews (${this.state.reviews.Count})`} />
                            <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6 }]}>View all</Text>
                        </View>
                        <View style={{ marginVertical: height(2.5) }}>
                        <ReviewsList data={this.state.reviews.Ratings} />
                        </View>

                    </View>
                </ScrollView>
                <Modal
                    visible={this.state.isMenuModalVisible}
                    transparent
                    animationType="slide"
                >
                    <View style={{ flex: 1, backgroundColor: '#00000080' }}>
                        <View style={{ flex: 7, backgroundColor: '#FFFF', borderBottomRightRadius: 10, borderBottomLeftRadius: 10 }}>
                            <View style={[ApplicationStyles.rowCompContainer, { marginHorizontal: 0, marginVertical: height(5) }]}>
                                <HeaderMenuIcon onPress={this.toggleMenuModal} />
                                <Text style={ApplicationStyles.h5}>Menu</Text>
                                <HeaderCloseIcon onPress={this.toggleMenuModal} />
                            </View>
                            {
                                !this.state.isLanguageOptionsVisible ?
                                    <View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.onClickEditProfile} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>Edit Profile</Text>
                                        </View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.manageLanguageOptions} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>Change language</Text>
                                        </View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.onClickLogout} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, color: colors.appColor1 }]}>Log Out</Text>
                                        </View>
                                    </View>
                                    :
                                    <View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.manageLanguageOptions} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, color: colors.appColor1 }]}>Eng</Text>
                                        </View>
                                        <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                            <Text onPress={this.manageLanguageOptions} style={[ApplicationStyles.h5, { fontFamily: family.appTextBold, }]}>RU</Text>
                                        </View>
                                    </View>
                            }
                        </View>
                        <View style={{ flex: 3 }}>

                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
}

export default UserProfile;

const styles = StyleSheet.create({
    title: {
        fontSize: totalSize(1.75)
    },
    subTitle: {
        fontFamily: family.appTextMedium
    },
    heading: {
        fontFamily: family.appTextBold
    },
    topDetail: {
        fontFamily: family.appTextLight
    },
    photoStyle: {
        height: totalSize(10),
        width: totalSize(10),
        borderRadius: 5,
        marginVertical: height(2.5),
        marginRight: width(2.5)
    },
    TitleUnderline: {
        width: width(40),
        borderBottomWidth: 0.5,
        borderBottomColor: colors.appTextColor6,
        marginTop: 2.5
    },
    bottomDetail: {
        fontFamily: family.appTextLight
    },
    reviewContainer: {
        marginHorizontal: width(5),
        backgroundColor: '#FFFF',
        borderRadius: 5,
        elevation: 5,
        marginVertical: height(1),
        //flexDirection: 'row',
        //alignItems: 'center'
    },
    ratingAreaContainer: {
        marginTop: 0
    }
})


