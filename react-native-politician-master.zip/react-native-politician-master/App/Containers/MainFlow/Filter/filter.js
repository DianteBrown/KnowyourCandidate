import React, { Component } from 'react';
import { View, Text, TextInput, FlatList, ScrollView, TouchableOpacity } from 'react-native';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import HeaderCloseIcon from '../../../Components/HeaderCloseIcon';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import colors from '../../../Themes/Colors';
import { Icon } from 'react-native-elements';
import { totalSize, width, height } from 'react-native-dimension';
import ButtonGroup from '../../../Components/ButtonGroup';
import HeadingUnderlined from '../../../Components/HeadingUnderlined';
import FilterItemsList from '../../../Components/FilterItemsList';

class Filter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            buttons: ['All News', 'Bills', 'Articals'],
            mainScrollEnables: true,
            states: [
                { name: 'State 1', selected: false },
                { name: 'State 2', selected: false },
                { name: 'State 3', selected: false },
                { name: 'State 4', selected: true },
                { name: 'State 5', selected: false },
                { name: 'State 6', selected: false },
                { name: 'State 7', selected: false }
            ],
            cities: [
                { name: 'City 1', selected: false },
                { name: 'City 2', selected: false },
                { name: 'City 3', selected: false },
                { name: 'City 4', selected: false },
                { name: 'City 5', selected: false },
                { name: 'City 6', selected: true },
                { name: 'City 7', selected: false }
            ],
            officies: [
                { name: 'President', selected: false },
                { name: 'House of Representative', selected: false },
                { name: 'Senate', selected: false },
                { name: 'Governor', selected: true },
                { name: 'Lieutenant governor', selected: false },
                { name: 'Secretary of state', selected: false },
                { name: 'Attorney general', selected: false }
            ]
        };
    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerStyle: { elevation: 0, backgroundColor: colors.appBgColor1 },
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />),
            headerTitle: "Filter",
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerRight: (<HeaderCloseIcon />)
        }
    }
    render() {
        return (
            <View style={ApplicationStyles.mainContainer}>
                <View style={[ApplicationStyles.inputContainerColored, { borderRadius: 100, backgroundColor: colors.appTextColor6, marginBottom: height(1) }]}>
                    <TextInput
                        placeholder="Search or enter zip code"
                        style={[ApplicationStyles.inputField, { width: width(70), height: height(6), fontSize: totalSize(1.25) }]}
                    />
                    <Icon name="search1" type="antdesign" size={totalSize(2)} />
                </View>
                <ButtonGroup buttons={this.state.buttons} />
                <ScrollView showsVerticalScrollIndicator={false}>
                    <HeadingUnderlined heading={'States'} />
                    <FilterItemsList data={this.state.states} />
                    <HeadingUnderlined heading={'Cities'} />
                    <FilterItemsList data={this.state.cities} />
                    <HeadingUnderlined heading={'Office'} subHeading={'political persons search'} />
                    <FilterItemsList data={this.state.officies} />

                    <TouchableOpacity onPress={() => this.props.navigation.goBack()} style={[ApplicationStyles.buttonColord, { marginVertical: height(5) }]}>
                        <Text style={ApplicationStyles.buttonText}>OK</Text>
                    </TouchableOpacity>
                </ScrollView>
            </View>
        );
    }
}

export default Filter;
