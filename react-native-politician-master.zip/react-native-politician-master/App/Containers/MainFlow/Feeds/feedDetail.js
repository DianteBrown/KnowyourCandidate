import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import FilterIcon from '../../../Components/FilterIcon';
import ButtonGroup from '../../../Components/ButtonGroup';
import ForumsList from '../../../Components/ForumsList';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import Heading from '../../../Components/Heading';
import ButtonResponsive from '../../../Components/ButtonResponsive';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';
class FeedDetail extends Component {
    static contextType = Context;
    constructor(props) {
        super(props);
        this.state = {
            detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
            comments: [],
            show_comment_input: false,
            comment : ''
        };
    }
    componentDidMount(){
        this.getComments()
    
    }

    getComments(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }


            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.get('news/get_news_comments?news_id='+this.props.navigation.state.params.data.news_id,header).then(response => {
                console.log(response.data)
                this.setState({
                    comments : response.data.comments
                })
            })
            }else{
                alert('error')
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })
    }

    Comment(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }

        const form = new FormData();
        form.append('news_id',this.props.navigation.state.params.data.news_id)
        form.append('text',this.state.comment);

            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.dashboardPost('news_comments',header,form).then(response => {
                // this.setState({
                //     comments : [...this.state.comments,response.data.text]
                // })
                // this.state.comments.push(response.data.text)
                // console.log(response);
                this.getComments()

            })
            }else{
                alert('error')
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })
    
    }
    static navigationOptions = ({ navigation }) => {
        return {
            title: navigation.state.params.data.title,
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filter')} />),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }
    toggleCommentInput = async () => {
         this.Comment();
        this.setState({ show_comment_input: !this.state.show_comment_input })}
    render() {
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={{ flex: 1 }}>
                        <View style={{ backgroundColor: '#FFFF', elevation: 5, borderRadius: 5, marginHorizontal: 0, marginVertical: 10 }}>
                            <Image source={{uri : this.props.navigation.state.params.data.image}} style={{ height: height(40), width: null, borderRadius: 5 }} />
                            <View style={{ position: 'absolute', bottom: totalSize(2.5), right: totalSize(2.5) }}>
                                <Icon name="ios-heart" type="ionicon" color="#FFFF" size={totalSize(4)} />
                            </View>
                        </View>
                        <View style={ApplicationStyles.rowCompContainer}>
                            <Heading heading={this.props.navigation.state.params.data.title} />
                            <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, }]}>15.09.19</Text>
                        </View>
                        <View style={[ApplicationStyles.compContainer, { marginTop: 0 }]}>
                            <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight, lineHeight: 12.5 }]}>{this.props.navigation.state.params.data.description}</Text>
                        </View>
                        <View style={ApplicationStyles.rowCompContainer}>
                            <Heading heading={'Comments'} />
                            <ButtonResponsive buttonText="Add a comment" onPress={()=>{        this.setState({ show_comment_input: !this.state.show_comment_input })}} />
                        </View>
                        <FlatList
                            showsVerticalScrollIndicator={false}
                            data={this.state.comments}
                            renderItem={({ item, index }) =>
                            <View style={{flex : 1}}>
                                <View style={[styles.commentContainer, { marginTop: index === 0 ? height(1) : 0, }]}>
                                    <View style={styles.commentSubContainer}>
                                        <View style={{ flex: 2, alignItems: 'flex-start' }}>
                                            <View style={{ backgroundColor: '#FFFF', elevation: 5, borderRadius: 100 }}>
                                                <Image source={{uri : item.user_profile_photo}} style={{ height: totalSize(5), width: totalSize(5), borderRadius: 100 }} />
                                            </View>
                                        </View>
                                        <View style={{ flex: 8 }}>
                                            <View style={styles.usernameContainer}>
        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>{item.user_name}</Text>
                                                <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, fontSize: totalSize(1) }]}>10.06.20</Text>
                                            </View>
                                            <View style={styles.CommentContainer}>
        {/* <Text style={[ApplicationStyles.h6, { fontSize: totalSize(1), }]}>{item.user_name}</Text> */}
                                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight, fontSize: totalSize(1), lineHeight: 10 }]}>{item.text}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                {item.replies.map(i => {
                                return <View style={[styles.commentReplyContainer, { marginTop: index === 0 ? height(1) : 0, }]}>
                                    <View style={styles.commentSubContainer}>
                                        <View style={{ flex: 2, alignItems: 'flex-start' }}>
                                            <View style={{ backgroundColor: '#FFFF', elevation: 5, borderRadius: 100 }}>
                                                <Image source={{uri : item.user_profile_photo}} style={{ height: totalSize(5), width: totalSize(5), borderRadius: 100 }} />
                                            </View>
                                        </View>
                                        <View style={{ flex: 8 }}>
                                            <View style={styles.usernameContainer}>
        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>{item.user_name}</Text>
                                                <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, fontSize: totalSize(1) }]}>10.06.20</Text>
                                            </View>
                                            <View style={styles.CommentContainer}>
        {/* <Text style={[ApplicationStyles.h6, { fontSize: totalSize(1), }]}>{item.user_name}</Text> */}
                                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight, fontSize: totalSize(1), lineHeight: 10 }]}>{this.state.detail}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                })}
                            </View>
                            }
                        />
                    </View>
                </ScrollView>
                {
                    this.state.show_comment_input ?
                        <View style={{ position: 'absolute', bottom: 0, right: 0, left: 0, elevation: 5, backgroundColor: '#FFFF' }}>
                            <View style={[ApplicationStyles.inputContainerColored, { borderRadius: 100, backgroundColor: 'transparent', marginVertical: height(2) }]}>
                                <TextInput
                                    placeholder="Aa..."
                                    autoFocus
                                    onBlur={this.toggleCommentInput}
                                    style={[ApplicationStyles.inputField, { width: width(70), height: height(6), paddingLeft: 10, fontSize: totalSize(1.25), backgroundColor: colors.appTextColor6, borderRadius: 100 }]}
                                    onChangeText={(val)=>{
                                        this.setState({
                                            comment : val
                                        })
                                    }}
                                />
                                <Icon name="md-send" type="ionicon" size={totalSize(3)} color={colors.appColor1} onPress={this.toggleCommentInput} />
                            </View>
                        </View>
                        :
                        null
                }
            </View>
        );
    }
}

export default FeedDetail;

const styles = StyleSheet.create({
    commentContainer: {
        marginRight: width(7.5),
        marginLeft: width(7.5),
        backgroundColor: '#FFFF',
        borderRadius: 10,
        elevation: 5,
        marginVertical: height(2.5)
    },
    commentSubContainer: {
        marginHorizontal: width(5),
        marginVertical: height(2.5),
        flexDirection: 'row',
    },
    usernameContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    commentReplyContainer: {
        marginRight: width(2.5),
        marginLeft: width(15),
        backgroundColor: '#FFFF',
        borderRadius: 10,
        elevation: 5,
        marginVertical: height(1)
    },
})