import React, { Component } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView, AsyncStorage } from 'react-native';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import images from '../../../Themes/Images';
import FilterIcon from '../../../Components/FilterIcon';
import FeedsList from '../../../Components/FeedsList';
import ButtonGroup from '../../../Components/ButtonGroup';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
class FavoriteFeeds extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            selectedIndex: 0,
            buttons: ['New', 'Featured', 'Popular'],
            feeds: [
                { title: 'Music Festival', image: images.f1, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: 'Music Festival', image: images.f1, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: 'Music Festival', image: images.f1, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: 'Music Festival', image: images.f1, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' }
            ],
        };
    }
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Favorite News",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filter')} />),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ButtonGroup
                    buttons={this.state.buttons}
                />
                <FeedsList feeds={this.state.feeds} onPress={() => navigate('feedDetail')} />
            </View>
        );
    }
}

export default FavoriteFeeds;
