import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import FilterIcon from '../../../Components/FilterIcon';
import FeedsList from '../../../Components/FeedsList';
import ButtonGroup from '../../../Components/ButtonGroup';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';
class Feeds extends Component {
    static contextType = Context;
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            selectedIndex: 0,
            buttons: ['New', 'Featured', 'Popular'],
            newFeeds : [],
            featuredFeeds : [],
            popularFeeds : [],
            selected : 'New',
            feeds: [
                { title: 'Music Festival', image: images.f1, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: 'Music Festival', image: images.f1, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: 'Music Festival', image: images.f1, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: true, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: 'Music Festival', image: images.f1, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' },
                { title: '7th Royal Dinner', image: images.f2, liked: false, feedDetail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five' }
            ],
        };
        this.updateIndex = this.updateIndex.bind(this)
    }

    componentDidMount(){
        this.getData();
        this.props.navigation.addListener("didFocus", (payload) => {
            this.getData()
        })
    }

    getData(){

        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }
            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.get('news/new_news',header).then(response => {
                this.setState({
                    newFeeds : response.data
                })
            })
            WService.get('news/papular_news',header).then(response => {
                console.log(response)
                this.setState({
                    popularFeeds : response.data
                })
            })
            WService.get('news/featured_news',header).then(response => {
                console.log(response)

                this.setState({
                    featuredFeeds : response.data
                })
            })
            }else{
                alert(this.context.state.languageWords.no_internet_connectivity)
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })

    }
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Your feed",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filter')} />),
            headerLeft: (<HeaderMenuIcon />)
        }
    }
    updateIndex(index) {
        this.setState({ selectedIndex: index })
    }

    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ButtonGroup
                    buttons={this.state.buttons}
                    selected={(val)=>{this.setState({
                        selected : val
                    })}}
                />
                {this.screens()}
            </View>
        );
    }

    screens=()=>{
        const navigate = this.props.navigation.navigate

        if(this.state.selected == 'New'){
           return <FeedsList feeds={this.state.newFeeds}  navigate = {navigate}/>
        }
        else if(this.state.selected == 'Featured'){
            return <FeedsList feeds={this.state.featuredFeeds} navigate = {navigate} />
         }
         else if(this.state.selected == 'Popular'){
            return <FeedsList feeds={this.state.popularFeeds} navigate = {navigate} />
         }
    }
}

export default Feeds;

