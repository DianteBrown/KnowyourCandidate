import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import FilterIcon from '../../../Components/FilterIcon';
import ButtonGroup from '../../../Components/ButtonGroup';
import ForumsList from '../../../Components/ForumsList';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';
class ForumDetail extends Component {
    static contextType= Context;
    constructor(props) {
        super(props);
        this.state = {
            detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
            replies: [1, 2, 3, 4, 5],
            show_comment_input: false,
            isRatingModalVisible: false,
            comments : [],
            comment : '',
            rate : 4,
            review : ''

        };
    }

    componentDidMount(){
        this.getComments()
    
    }

    Comment(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }

        const form = new FormData();
        form.append('forum_id',this.props.navigation.state.params.data.forum_id)
        form.append('text',this.state.comment);

            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.dashboardPost('forum_comments',header,form).then(response => {
                // this.setState({
                //     comments : [...this.state.comments,response.data.text]
                // })
                // this.state.comments.push(response.data.text)
                // console.log(response);
                this.getComments()

            })
            }else{
                alert('error')
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })
    
    }

    Review(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }

        const form = new FormData();
        form.append('forum_id',this.props.navigation.state.params.data.forum_id)
        form.append('review',this.state.review);
        form.append('rate', JSON.stringify(this.state.rate));

        console.log(form)

            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.dashboardPut('forums/add_ratings',header,form).then(response => {
                // this.setState({
                //     comments : [...this.state.comments,response.data.text]
                // })
                // this.state.comments.push(response.data.text)
                alert(response.data.message);
                // this.getComments()

            })
            }else{
                alert('error')
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })
    
    }

    getComments(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }


            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.get('forums/get_forum_comments?forum_id='+this.props.navigation.state.params.data.forum_id,header).then(response => {
                console.log(response.data)
                this.setState({
                    comments : response.data.comments
                })
            })
            }else{
                alert('error')
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err)
        })
    }

    static navigationOptions = ({ navigation }) => {
        return {
            title: "Topic",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filterForum')} />),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }
    toggleRatingModal = () => this.setState({ isRatingModalVisible: !this.state.isRatingModalVisible })
    render() {
        return (
            <View style={ApplicationStyles.mainContainer}>
                <View style={{ position: 'absolute', top: height(5), left: width(20), height: height(80), borderRightWidth: 0.5, borderRightColor: colors.appTextColor5 }}>
                </View>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={{ flex: 1 }}>
                        <View style={styles.forumContainer}>
                            <View style={styles.forumSubContainer}>
                                <View style={styles.titleContainer}>
        <Text style={[ApplicationStyles.h5, { fontFamily: family.appTextBold }]}>{this.props.navigation.state.params.data.title}</Text>
                                    <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, fontSize: totalSize(1) }]}>07.10.19</Text>
                                </View>
                                <View style={styles.detailContainer}>
                                    <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight, fontSize: totalSize(1), lineHeight: 10 }]}>{this.props.navigation.state.params.data.description}</Text>
                                </View>
                                <View style={styles.replyButtonContainer}>
                                    <TouchableOpacity onPress={this.toggleRatingModal} activeOpacity={1} style={{ flexDirection: 'row', alignItems: 'center', }}>
                                        <Icon name="star" type="font-awesome" size={totalSize(1.25)} color={colors.appColor1} />
                                        <Text style={[ApplicationStyles.h6, { color: colors.appColor1, fontSize: totalSize(1) }]}> Rate</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => this.setState({ show_comment_input: true })} activeOpacity={1} style={{ flexDirection: 'row', alignItems: 'center', }}>
                                        <Icon name="reply" type="material-community" size={totalSize(1.5)} color={colors.appTextColor5} />
                                        <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, fontSize: totalSize(1) }]}> Reply</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                        <FlatList
                            showsVerticalScrollIndicator={false}
                            data={this.state.comments}
                            renderItem={({ item, index }) =>
                                <View style={[styles.replyContainer, { marginTop: index === 0 ? height(1) : 0 }]}>
                                    <View style={styles.replySubContainer}>
                                        <View style={{ flex: 2, alignItems: 'flex-start' }}>
                                            <View style={{ backgroundColor: '#FFFF', elevation: 5, borderRadius: 100 }}>
                                                <Image source={{uri : item.user_profile_photo}} style={{ height: totalSize(5), width: totalSize(5), borderRadius: 100 }} />
                                            </View>
                                        </View>
                                        <View style={{ flex: 8 }}>
                                            <View style={styles.usernameContainer}>
        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>{item.user_name}</Text>
                                                <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, fontSize: totalSize(1) }]}>10.06.20</Text>
                                            </View>
                                            <View style={styles.CommentContainer}>
                                                {/* <Text style={[ApplicationStyles.h6, { fontSize: totalSize(1), }]}>Lorem Ipsum</Text> */}
                                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight, fontSize: totalSize(1), lineHeight: 10 }]}>{item.text}</Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            }
                        />
                    </View>
                </ScrollView>
                {
                    this.state.show_comment_input ?
                        <View style={{ position: 'absolute', bottom: 0, right: 0, left: 0, elevation: 5, backgroundColor: '#FFFF' }}>
                            <View style={[ApplicationStyles.inputContainerColored, { borderRadius: 100, backgroundColor: 'transparent', marginVertical: height(2) }]}>
                                <TextInput
                                    placeholder="Aa..."
                                    autoFocus
                                    onBlur={() => this.setState({ show_comment_input: false })}
                                    onChangeText={(val)=>{this.setState({
                                        comment : val
                                    })}}
                                    style={[ApplicationStyles.inputField, { width: width(70), height: height(6), paddingLeft: 10, fontSize: totalSize(1.25), backgroundColor: colors.appTextColor6, borderRadius: 100 }]}
                                />
                                <Icon name="md-send" type="ionicon" size={totalSize(3)} color={colors.appColor1} onPress={() => {this.setState({ show_comment_input: false });this.Comment()}} />
                            </View>
                        </View>
                        :
                        null
                }
                <Modal
                    visible={this.state.isRatingModalVisible}
                    transparent
                    animationType="slide"
                >
                    <View style={{ flex: 1, justifyContent: 'center', backgroundColor: '#00000080' }}>
                        <View style={{ marginHorizontal: 0, backgroundColor: '#FFFF', borderRadius: 25 }}>
                            <View style={[ApplicationStyles.rowCompContainer, {}]}>
                                <Text style={[ApplicationStyles.h4, styles.title]}>Write your review</Text>
                                <Icon name="ios-close" type="ionicon" onPress={this.toggleRatingModal} size={totalSize(2.5)} />
                            </View>
                            <View style={[ApplicationStyles.rowCompContainer, styles.ratingAreaContainer]}>
                                <View>
                                    <Text style={[ApplicationStyles.h5, styles.subTitle]}>Tap to rate</Text>
                                </View>
                                <View>
                                    <StarRating
                                        emptyStar={'ios-star'}
                                        fullStar={'ios-star'}
                                        halfStar={'ios-star-half'}
                                        iconSet={'Ionicons'}
                                        maxStars={5}
                                        starStyle={{ marginRight: 5 }}
                                        starSize={totalSize(2.5)}
                                        rating={this.state.rate}
                                        selectedStar={(rating) => {this.setState({rate : rating})}}
                                        emptyStarColor={colors.appTextColor5}
                                        fullStarColor={colors.appColor1}
                                    />
                                </View>
                            </View>
                            <TextInput
                            onChangeText={(val)=>{this.setState({
                                review : val
                            })}}
                                placeholder="Type your review here..."
                                multiline
                                scrollEnabled
                                style={{ marginHorizontal: width(5), textAlignVertical: 'top', height: height(20), fontSize: totalSize(1.5), fontFamily: family.appTextRegular }}
                            />
                            <TouchableOpacity onPress={()=>{this.Review(); this.toggleRatingModal();}} activeOpacity={1} style={[ApplicationStyles.buttonColord, { marginVertical: height(2.5) }]}>
                                <Text style={ApplicationStyles.buttonText}>Post</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={{ position: 'absolute', top: 0, right: 0 }}>

                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
}

export default ForumDetail;

const styles = StyleSheet.create({
    forumContainer: {
        marginHorizontal: width(5),
        backgroundColor: '#FFFF',
        borderRadius: 10,
        elevation: 5,
        marginVertical: height(1.5)
    },
    forumSubContainer: {
        marginHorizontal: width(5),
        marginVertical: height(2.5)
    },
    titleContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    detailContainer: {
        marginVertical: height(2)
    },
    replyButtonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignContent: 'center'
    },
    replyContainer: {
        marginRight: width(2),
        marginLeft: width(10),
        backgroundColor: '#FFFF',
        borderRadius: 10,
        elevation: 5,
        marginVertical: height(1.5)
    },
    replySubContainer: {
        marginHorizontal: width(5),
        marginVertical: height(2.5),
        flexDirection: 'row',
    },
    usernameContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    CommentContainer: {
        marginTop: height(1)
    },
})