import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import FilterIcon from '../../../Components/FilterIcon';
import ButtonGroup from '../../../Components/ButtonGroup';
import ForumsList from '../../../Components/ForumsList';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';
class Forum extends Component {
    static contextType = Context
    constructor(props) {
        super(props);
        this.state = {
            forums: [
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                }
            ],
            buttons: ['New', 'Featured', 'Popular'],
            selected : 'New',
            newForums : [],
            featuredForums : [],
            popularForums : []
        };
    }

    componentDidMount(){
        this.getData()

        this.props.navigation.addListener("didFocus", (payload) => {
            this.getData()
        })
        
    
    }

    getData(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }
            NetInfo.fetch().then(state => {
            this.setState({loader : true})
            if(state.isConnected){
            WService.get('forums/new_forums',header).then(response => {
                this.setState({
                    newForums : response.data
                })
            })
            WService.get('forums/papular_forums',header).then(response => {
                console.log(response)
                this.setState({
                    popularForums : response.data
                })
            })
            WService.get('forums/featured_forums',header).then(response => {
                console.log(response)

                this.setState({
                    featuredForums : response.data
                })
            })
            }else{
                alert(this.context.state.languageWords.no_internet_connectivity)
                this.setState({loader : false})
            }
    
        }).catch(err => {
            alert(err.message)
        })
    }

    static navigationOptions = ({ navigation }) => {
        return {
            title: "Forum",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filterForum')} />),
            headerLeft: (<HeaderMenuIcon />)
        }
    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <ButtonGroup
                    buttons={this.state.buttons}
                    selected={(val)=>{this.setState({
                        selected : val
                    })}}
                />
                {/* <ForumsList forums={this.state.forums} onPress={() => navigate('forumDetail')} /> */}
                {this.screens()}
            </View>
        );
    }
    screens=()=>{
        const navigate = this.props.navigation.navigate

        if(this.state.selected == 'New'){
           return <ForumsList forums={this.state.newForums}  navigate = {navigate}/>
        }
        else if(this.state.selected == 'Featured'){
            return <ForumsList forums={this.state.featuredForums} navigate = {navigate} />
         }
         else if(this.state.selected == 'Popular'){
            return <ForumsList forums={this.state.popularForums} navigate = {navigate} />
         }
    }
}

export default Forum;

