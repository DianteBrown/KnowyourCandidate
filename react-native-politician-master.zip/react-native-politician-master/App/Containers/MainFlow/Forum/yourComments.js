import React, { Component } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, FlatList, ScrollView, Modal, TextInput } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { height, totalSize, width } from 'react-native-dimension';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import colors from '../../../Themes/Colors';
import { Icon, Rating } from 'react-native-elements';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import StarRating from 'react-native-star-rating';
import FilterIcon from '../../../Components/FilterIcon';
import ButtonGroup from '../../../Components/ButtonGroup';
import ForumsList from '../../../Components/ForumsList';
import HeaderBackArrow from '../../../Components/HeaderBackArrow';
import Heading from '../../../Components/Heading';
import ButtonResponsive from '../../../Components/ButtonResponsive';

class YourComments extends Component {
    static navigationOptions = ({ navigation }) => {
        return {
            title: "Forum",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<FilterIcon onPress={() => navigation.navigate('filter')} />),
            headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
        }
    }
    constructor(props) {
        super(props);
        this.state = {
            forums: [
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                },
                {
                    title: 'Article Title',
                    forum_Detail: 'News Title Lorem Ipsum is simply dummy text of thewhen an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five',
                    comments: '45343'
                }
            ],
            buttons: ['New', 'Featured', 'Popular'],
        };
    }

    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <View style={ApplicationStyles.rowCompContainer}>
                    <Heading heading={'Your comments (10)'} />
                    <TouchableOpacity activeOpacity={1} style={{ backgroundColor: colors.appColor1, borderRadius: 100, }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginHorizontal: 10, marginVertical: 2.5 }}>
                            <Text style={[ApplicationStyles.h6, { color: '#FFFF' }]}>See all </Text>
                            <Icon name="close" size={totalSize(1.5)} color={'#FFFF'} />
                        </View>
                    </TouchableOpacity>
                </View>
                <ForumsList forums={this.state.forums} onPress={() => navigate('forumDetail')} />
            </View>
        );
    }
}

export default YourComments;

