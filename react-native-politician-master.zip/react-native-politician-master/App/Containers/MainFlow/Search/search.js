import React, { Component } from 'react';
import { View, Text, TextInput, ScrollView, Image } from 'react-native';
import ApplicationStyles from '../../../Themes/ApplicationStyles';
import { Icon } from 'react-native-elements';
import { totalSize, width, height } from 'react-native-dimension';
import colors from '../../../Themes/Colors';
import images from '../../../Themes/Images';
import family from '../../../Themes/Fonts';
import UsersListHorizontal from '../../../Components/UsersListHorizontal';
import PoliticianListHorizontal from '../../../Components/PoliticianListHorizontal';
import UsersListVertical from '../../../Components/UsersListVertical';
import HeaderMenuIcon from '../../../Components/HeaderMenuIcon';
import FilterIcon from '../../../Components/FilterIcon';
import WService from '../../../../apis/index';
import NetInfo from "@react-native-community/netinfo";
import {Context} from '../../../contextApi';

class Search extends Component {
    static contextType = Context;
    constructor(props) {
        super(props);
        this.state = {
            users: [],
            politicians : [],
            isSearchFocused: false,
            search_qurey: '',
            search : []
        };
    }
    onDissmissSearch = () => {
        this.setState({ isSearchFocused: false, search_qurey: '' })

    }

    componentDidMount(){
        this.props.navigation.addListener("didFocus", (payload) => {
            this.Users()
        })
        this.Users()
        // this.Politicians()
    }

    Users(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }
        NetInfo.fetch().then(state => {
        this.setState({loader : true})
        if(state.isConnected){
        WService.get('users/suggested_users',header).then(response => {
            this.setState({
                users : response.data
            })
        })
        WService.get('users/suggested_politicians',header).then(response => {
            this.setState({
                politicians : response.data
            })
        })
        }else{
            alert(this.context.state.languageWords.no_internet_connectivity)
            this.setState({loader : false})
        }

    }).catch(err => {
        alert(err)
    })

    }

    Search(){
        const header = {
            id : this.context.state.user.UUID,
            auth : this.context.state.user.Authentication,
        }
        NetInfo.fetch().then(state => {
        this.setState({loader : true})
        if(state.isConnected){
        WService.get('users/search?query='+this.state.search_qurey,header).then(response => {
            console.warn(response.data)
            this.setState({
                search : response.data
            })
        })
        // WService.get('users/suggested_politicians',header).then(response => {
        //     console.warn(response.data)

        //     this.setState({
        //         politicians : response.data
        //     })
        // })
        }else{
            alert(this.context.state.languageWords.no_internet_connectivity)
            this.setState({loader : false})
        }

    }).catch(err => {
        alert(err)
    })

    }

    // Politicians(){
    //     const header = {
    //         id : this.context.state.user.UUID,
    //         auth : this.context.state.user.Authentication,
    //     }
    //     NetInfo.fetch().then(state => {
    //     this.setState({loader : true})
    //     if(state.isConnected){
    //     WService.get('users/suggested_politicians',header).then(response => {
    //         this.setState({
    //             politicians : response.data
    //         })
    //     }).catch(err => {
    //         alert(err.message)
    //     })
    //     }else{
    //         alert(this.context.state.languageWords.no_internet_connectivity)
    //         this.setState({loader : false})
    //     }

    // }).catch(err => {
    //     alert(err.message)
    // })

    // }

    static navigationOptions = ({ navigation }) => {
        return {
            title: "Search",
            headerStyle: { elevation: 0 },
            headerTitleContainerStyle: { alignItems: 'center', justifyContent: 'center' },
            headerTitleStyle: ApplicationStyles.headerTitleStyles,
            headerRight: (<Icon name="bell-outline" type="material-community" color={colors.appTextColor1} size={totalSize(2.5)} iconStyle={{ marginRight: width(5) }} />),
            headerLeft: (<HeaderMenuIcon />)
        }
    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={ApplicationStyles.mainContainer}>
                <View style={[ApplicationStyles.inputContainerColored, { backgroundColor: colors.appTextColor6, borderRadius: 100, marginHorizontal: width(5) }]}>
                    <Icon name="ios-search" type="ionicon" size={totalSize(2.5)} color={colors.appTextColor5} />
                    <TextInput
                        placeholder="Search Politician or User"
                        onChangeText={(value) => this.setState({ search_qurey: value })}
                        onFocus={() => this.setState({ isSearchFocused: true })}
                        value={this.state.search_qurey}
                        style={[ApplicationStyles.inputField, { width: width(70), height: height(6) }]}
                        onSubmitEditing={()=>{
                                this.Search()
                        }}
                    />
                    <Icon onPress={this.onDissmissSearch} name="ios-close" type="ionicon" size={totalSize(2.5)} color={this.state.isSearchFocused ? colors.appTextColor3 : 'transparent'} />
                </View>
                {
                    this.state.isSearchFocused ?
                        <View>
                            <UsersListVertical data={this.state.search} navigate={navigate}/>
                        </View>
                        :
                        <View>
                            <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                <Text style={ApplicationStyles.h4}>Suggested Users</Text>
                            </View>
                            <UsersListHorizontal data={this.state.users} navigate={navigate} />
                            <View style={[ApplicationStyles.compContainer, { marginBottom: 0 }]}>
                                <Text style={ApplicationStyles.h4}>Suggested Politicians</Text>
                            </View>
                            <PoliticianListHorizontal data={this.state.politicians} onPress={() => navigate('viewPoliticalProfile')} />

                        </View>
                }
            </View>
        );
    }
}

export default Search;
