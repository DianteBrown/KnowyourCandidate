import React, { Component } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet,ActivityIndicator, Image, ScrollView } from 'react-native';
import ApplicationStyles from '../../Themes/ApplicationStyles';
import { height, width, totalSize } from 'react-native-dimension';
import colors from '../../Themes/Colors';
import images from '../../Themes/Images';
import family from '../../Themes/Fonts';
import Modal from 'react-native-modal';
import NetInfo from "@react-native-community/netinfo";
import ImagePicker from 'react-native-image-picker';
import GetLocation from 'react-native-get-location';
import Geocoder from 'react-native-geocoder';
import MIcon from "react-native-vector-icons/MaterialIcons";
import MCIcon from "react-native-vector-icons/MaterialCommunityIcons";
import AIcon from "react-native-vector-icons/AntDesign";
import EIcon from "react-native-vector-icons/Entypo";
import FIcon from "react-native-vector-icons/Feather";
import OIcon from "react-native-vector-icons/Octicons";
import FontistoIcon from "react-native-vector-icons/Fontisto";
import WService from '../../../apis/index';

const options = {
    title: "Select Photo",
  
    takePhotoButtonTitle: "Take Photo…",
    chooseFromLibraryButtonTitle: "Choose from Gallery"
  };

class Signup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isEamilSentModalVisible: false,
            isConfirmedModalVisible: false,
            card_numer: '1111 1111 1111 1111',
            cvc: '123',
            valid_thru: '09/24',
            name: 'Name Name',
            photo : '',
            city : '',
            country : '',
            locationName : "",
            username : '',
            email : '',
            password : '',
            passwordAgain : '',
            fullName : '',
            loader : false
        };
    }
    toggleEmailSentModal = () => this.setState({ isEamilSentModalVisible: !this.state.isEamilSentModalVisible })
    toggleConfirmedModal = () => this.setState({ isConfirmedModalVisible: !this.state.isConfirmedModalVisible })

    onPressGo = () => {
        this.toggleEmailSentModal()
        setTimeout(() => {
            this.toggleEmailSentModal()
            this.toggleConfirmedModal()
        }, 2000);

    }

    componentDidMount(){
        this.selectLocation()
    }
    
    openGallery = () => {
        ImagePicker.showImagePicker(options, response => {
          if (response.didCancel) {
            console.log("User cancelled image picker");
          } else if (response.error) {
            console.log("ImagePicker Error: ", response.error);
          } else if (response.customButton) {
            console.log("User tapped custom button: ", response.customButton);
          } else {
            this.setState({ photo: response });
            this.state.photo['name'] = response.fileName;
            this.state.photo['size'] = response.fileSize;
    
            
            console.log('i1' + response)
          }
        });
      };

      selectLocation() {
    
        // this.setState({currentLocation : false})
        GetLocation.getCurrentPosition({
          enableHighAccuracy: true,
          timeout: 15000,
        })
          .then(async location => {
            // let currentUserId = await _retrieveData(GlobalConst.STORAGE_KEYS.userId);
            Geocoder.geocodePosition(
              {
                lat: location.latitude,
                lng: location.longitude
              }
            ).then(res => {
            //   var jsonObject = {
            //     locationName : res[0].formattedAddress.split(',')[0]+res[0].formattedAddress.split(',')[1]+res[0].formattedAddress.split(',')[2]
            //   }
              this.setState({
                locationName : res[0].formattedAddress.split(',')[2]+res[0].formattedAddress.split(',')[res[0].formattedAddress.split(',').length-1],
                city : res[0].formattedAddress.split(',')[2],
                country : res[0].formattedAddress.split(',')[res[0].formattedAddress.split(',').length-1]
              })
            //   saveData('users',currentUserId,jsonObject)  
            // alert(res[0].formattedAddress)
            })
            .catch(err => console.log(err))
          })
          .catch(error => {
            const { code, message } = error;
            alert("ERROR : " + message)
        //    this.setState({currentLocation : false})
          
          })
    
          return 0;
      }  

    Signup(){
        this.setState({
            loader : true
        })
        const form = new FormData();
        form.append('email',this.state.email);
        form.append('full_name',this.state.fullName)
        form.append('user_name',this.state.username)
        form.append('role','User')
        form.append('profile_photo',this.state.photo)
        form.append('password',this.state.password)
        form.append('city',this.state.city)
        form.append('country',this.state.country)



        NetInfo.fetch().then(state => {
        this.setState({loader : true})
        if(state.isConnected){
            console.log('running')
        WService.post('users/sign_up', form).then(response => {
            console.warn(response)
            this.setState({
                loader : false
            })
            this.props.navigation.navigate('login')
            // if(response.data.success == 1){
            //     _storeData('user',response.data.data.user.token)
            //     _storeData('red_alert_auth',response.data.data.permissions.redalertauth)
            //     this.context.setUser(response.data.data.user.token)
            //     this.context.setRedAlertAuth(response.data.data.permissions.redalertauth)
            //     // alert(response.data.data.permissions.redalertauth)
            //     if(response.data.data.permissions.alerts ==true && response.data.data.permissions.showmap ==true)
            //     this.props.navigation.navigate('mainAll')
            //     else if(response.data.data.permissions.alerts == false && response.data.data.permissions.showmap ==false)
            //     this.props.navigation.navigate('mainHome')
            //     else if(response.data.data.permissions.alerts)
            //     this.props.navigation.navigate('mainHomeAlert')
            //     else if(response.data.data.permissions.showmap)
            //     this.props.navigation.navigate('mainHomeMap')

            //     this.setState({loader : false})
            // }else{
            //     alert(this.context.state.languageWords.invalid_credentials)
            //     this.setState({loader : false, emailColor : 'orange', passwordColor : 'orange'})
            // }
        }).catch(err => {
            alert('Invalid Credentials')
            this.setState({
                loader : false
            })
        })
        }else{
            alert(this.context.state.languageWords.no_internet_connectivity)
            this.setState({loader : false})
        }

    }).catch(err => {
        alert(err.message)
        this.setState({
            loader : false
        })
    })

    }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={[ApplicationStyles.mainContainer, { justifyContent: 'center' }]}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={{ height: height(18), justifyContent : 'center', alignItems : 'center' }}>
                        <TouchableOpacity onPress={()=>this.openGallery()} style={{width : width(24), height : width(24), borderRadius : width(24)/2, justifyContent : 'center', alignItems : 'center'}}>
                            {this.state.photo == '' ? <Text>Select Photo</Text> : <Image source={{uri : this.state.photo.uri}} style={{width : width(24), height : width(24), borderRadius : width(24)/2}}></Image>}
                        </TouchableOpacity>
                    </View>
                    <View style={[ApplicationStyles.inputFieldUnderlined, styles.inputField,{flexDirection : 'row', alignItems : 'center'}]}>
                        <View style={{flex : 1}}>
                    <TextInput
                        placeholder="Username"
                        style={[ApplicationStyles.h5]}
                        onChangeText={val => {
                            if(this.validateName(val))
                            this.setState({
                                username : val
                            })
                            else
                            this.setState({
                                username : ''
                            })
                        }}
                    />
                    </View>
                    {this.state.username == '' ?
                                            <AIcon name='exclamationcircleo' color='red' size={15}></AIcon>
                                            : null}

                    </View>
                    <View style={[ApplicationStyles.inputFieldUnderlined, styles.inputField,{flexDirection : 'row', alignItems : 'center'}]}>
                        <View style={{flex : 1}}>
                    <TextInput
                        placeholder="fullname"
                        style={[ApplicationStyles.h5]}
                        onChangeText={val => {
                            if(this.validateName(val)){
                                this.setState({
                                fullName : val
                            })
                            }
                            else
                            this.setState({
                                fullName : ''
                            })
                        }}

                    />
                                        </View>
                    {this.state.fullName == '' ?
                                            <AIcon name='exclamationcircleo' color='red' size={15}></AIcon>
                                            : null}

                    </View>
                    <View style={[ApplicationStyles.inputFieldUnderlined, styles.inputField,{flexDirection : 'row', alignItems : 'center'}]}>
                        <View style={{flex : 1}}>
                    <TextInput
                        placeholder="Email"
                        style={[ApplicationStyles.h5]}
                        onChangeText={val => {
                            if(this.validateEmail(val)){
                                this.setState({
                                email : val
                            })
                        }
                            else
                            this.setState({
                                email : ''
                            })
                        }}

                    />
                    </View>
                    {this.state.email == '' ?
                                            <AIcon name='exclamationcircleo' color='red' size={15}></AIcon>
                                            : null}

                    </View>
                    <View style={[ApplicationStyles.inputFieldUnderlined, styles.inputField,{flexDirection : 'row', alignItems : 'center'}]}>
                        <View style={{flex : 1}}>
                    <TextInput
                        secureTextEntry
                        placeholder="Password"
                        style={[ApplicationStyles.h5]}
                        onChangeText={val => {
                            this.setState({
                                password : val
                            })
                        }}

                    />
                                        </View>
                    {this.state.password == '' ?
                                            <AIcon name='exclamationcircleo' color='red' size={15}></AIcon>
                                            : null}

                    </View>
                    <View style={[ApplicationStyles.inputFieldUnderlined, styles.inputField,{flexDirection : 'row', alignItems : 'center'}]}>
                        <View style={{flex : 1}}>
                    <TextInput
                        secureTextEntry
                        placeholder="Password again"
                        style={[ApplicationStyles.h5]}
                        onChangeText={val => {
                            this.setState({
                                passwordAgain : val
                            })
                        }}

                    />
                                        </View>
                    {this.state.passwordAgain == '' ?
                                            <AIcon name='exclamationcircleo' color='red' size={15}></AIcon>
                                            : null}

                    </View>
                    {this.state.locationName != '' ? 
                    <TextInput
                        secureTextEntry
                        placeholder={this.state.locationName}
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                        editable={false}
                    />
                    :
                    <TouchableOpacity onPress={()=>{this.selectLocation()}} style={[styles.inputField,{justifyContent : 'center', marginTop : 20, marginHorizontal : width(8)}]}>
                        <Text>Refresh for the location</Text>
                    </TouchableOpacity>
                    }
                    <View style={{ marginVertical: height(4) }}>
                        {this.state.username != '' && this.state.fullName != ''  && this.state.email != '' && JSON.stringify(this.state.password) == JSON.stringify(this.state.passwordAgain) && this.state.city != '' && this.state.country != '' && this.state.photo != ''
                        ?
                        <TouchableOpacity onPress={() => this.Signup()} style={[ApplicationStyles.buttonColord, {}]}>
                            {this.state.loader == false ? 
                            <Text style={ApplicationStyles.buttonText}>GO!</Text>
                            :
                                <ActivityIndicator size='small' color='white'></ActivityIndicator>
                            }                        
                        </TouchableOpacity>
                        :
                        <TouchableOpacity disabled={true} style={[ApplicationStyles.buttonColord, {opacity : .5}]}>
                            <Text style={ApplicationStyles.buttonText}>GO!</Text>
                        </TouchableOpacity>
                        } 
                        <View style={{ alignItems: 'center' }}>
                            <Text style={[ApplicationStyles.h6, { marginVertical: height(2.5), color: colors.appTextColor5 }]}>Already have an account?</Text>
                            <Text onPress={() => navigate('login')} style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>Login</Text>
                        </View>
                    </View>
                    <View style={{ alignItems: 'center' }}>
                        <Text style={[ApplicationStyles.h6, { marginVertical: height(2.5), color: colors.appTextColor5 }]}>Are you a political?</Text>
                        <Text onPress={() => navigate('signupPolitical')} style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>Sign Up</Text>
                    </View>
                </ScrollView>
                <Modal
                    //  onBackdropPress={this.toggleEmailSentModal}
                    isVisible={this.state.isEamilSentModalVisible}
                >
                    <View style={{ backgroundColor: '#FFFF', borderRadius: 10, marginHorizontal: width(10) }}>
                        <View style={{ alignItems: 'center', marginVertical: height(5) }}>
                            <Image source={images.sent_icon} resizeMode={"contain"} style={{ height: totalSize(10), width: totalSize(10) }} />
                        </View>
                        <View style={[ApplicationStyles.compContainer, { alignItems: 'center' }]}>
                            <Text style={[ApplicationStyles.h6, { textAlign: 'center' }]}>Confirmation has been sent to</Text>
                            <Text style={[ApplicationStyles.h5, { textAlign: 'center', color: colors.appColor1, fontFamily: family.appTextMedium }]}>jhonwick003@gmail.com</Text>
                        </View>
                    </View>
                </Modal>
                <Modal
                    onBackdropPress={this.toggleConfirmedModal}
                    isVisible={this.state.isConfirmedModalVisible}
                >
                    <View style={{ backgroundColor: '#FFFF', borderRadius: 10, marginHorizontal: width(10) }}>
                        <View style={{ alignItems: 'center', marginVertical: height(5) }}>
                            <Image source={images.done_icon} resizeMode={"contain"} style={{ height: totalSize(10), width: totalSize(10) }} />
                        </View>
                        <View style={[ApplicationStyles.compContainer, { alignItems: 'center', marginBottom: height(5) }]}>
                            <Text style={[ApplicationStyles.h5, { textAlign: 'center' }]}>Confirmed!</Text>
                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
    validateEmail = Cnic => {
        var re = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,9})$/;
        return re.test(Cnic);
      };
      validateName = name => {
        var re = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
        return re.test(name);
      };
      validateNumber = number => {
        var re = /^[0-9]{1,100}$/;
        return re.test(number);
      };
}



const styles = StyleSheet.create({
    inputField: {
        // marginTop: height(1),
    },
    card: {
        marginHorizontal: width(7.5),
        backgroundColor: colors.appColor1,
        borderRadius: 10,
        marginVertical: height(2.5)
    },
    cardText: {
        color: '#FFFFFF'
    }
})
export default Signup;
