import React, { Component } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView,ActivityIndicator, AsyncStorage } from 'react-native';
import ApplicationStyles from '../../Themes/ApplicationStyles';
import { height, width, totalSize } from 'react-native-dimension';
import colors from '../../Themes/Colors';
import images from '../../Themes/Images';
import Modal from 'react-native-modal'
import family from '../../Themes/Fonts';
import { CheckBox } from 'react-native-elements';
import NetInfo from "@react-native-community/netinfo";
import WService from '../../../apis/index';
import {Context} from '../../contextApi';


class Login extends Component {
    static contextType = Context;
    constructor(props) {
        super(props);
        this.state = {
            card_numer: '1111 1111 1111 1111',
            cvc: '123',
            valid_thru: '09/24',
            name: 'Name Name',
            checked: true,
            isPasswordSendModalVisible: false,
            email : '',
            password : '',
            loader : ''
        };
    }

    Login(){
        this.setState({
            loader : true
        })
        const navigate = this.props.navigation.navigate

        const form = new FormData();
        form.append('email',this.state.email.toLowerCase());
        form.append('password',this.state.password)
        



        NetInfo.fetch().then(state => {
        this.setState({loader : true})
        if(state.isConnected){
        WService.post('users/sign_in', form).then(response => {
            console.warn(response)
            this.setState({
                loader : false
            })
            if(response.data.role == 'User'){
                this.context.setUser(response.data)
                navigate('UserApp')
            }else{
                this.context.setUser(response.data)
                navigate('PoliticianApp')
            }
            
            // if(response.data.success == 1){
            //     _storeData('user',response.data.data.user.token)
            //     _storeData('red_alert_auth',response.data.data.permissions.redalertauth)
            //     this.context.setUser(response.data.data.user.token)
            //     this.context.setRedAlertAuth(response.data.data.permissions.redalertauth)
            //     // alert(response.data.data.permissions.redalertauth)
            //     if(response.data.data.permissions.alerts ==true && response.data.data.permissions.showmap ==true)
            //     this.props.navigation.navigate('mainAll')
            //     else if(response.data.data.permissions.alerts == false && response.data.data.permissions.showmap ==false)
            //     this.props.navigation.navigate('mainHome')
            //     else if(response.data.data.permissions.alerts)
            //     this.props.navigation.navigate('mainHomeAlert')
            //     else if(response.data.data.permissions.showmap)
            //     this.props.navigation.navigate('mainHomeMap')

            //     this.setState({loader : false})
            // }else{
            //     alert(this.context.state.languageWords.invalid_credentials)
            //     this.setState({loader : false, emailColor : 'orange', passwordColor : 'orange'})
            // }
        }).catch(err => {
            alert('Invalid Credentials')
            this.setState({
                loader : false
            })
        })
        }else{
            alert('Invalid Credentials')
            this.setState({loader : false})
        }

    }).catch(err => {
        alert(err.response)
        this.setState({
            loader : false
        })
    })

    }
    togglePasswordSendModal = () => this.setState({ isPasswordSendModalVisible: !this.state.isPasswordSendModalVisible })
    componentDidMount = async () => {
        await AsyncStorage.setItem('UserType', 'user')
    }
    onUserCheck = async () => {
        await AsyncStorage.setItem('UserType', 'user')
        this.setState({ checked: true })
    }
    onPoliticianCheck = async () => {
        await AsyncStorage.setItem('UserType', 'politician')
        this.setState({ checked: false })
    }
    // onLogin = async () => {
    //     if (this.state.checked) {
    //     } else { navigate('PoliticianApp') }
    // }
    render() {
        const navigate = this.props.navigation.navigate
        return (
            <View style={[ApplicationStyles.mainContainer, { justifyContent: 'center' }]}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <View style={{ height: height(30) }}></View>
                    <TextInput
                        onChangeText={(val) => {
                            if(this.validateEmail(val)){
                                this.setState({
                                email : val
                            })
                        }
                            else
                            this.setState({
                                email : ''
                            })
                        }}
                        placeholder="Email"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    <TextInput
                        onChangeText={(value) => this.setState({ password: value })}
                        placeholder="Password"
                        style={[ApplicationStyles.inputFieldUnderlined, styles.inputField]}
                    />
                    {/* <View style={{ marginHorizontal: 0, flexDirection: 'row', alignItems: 'center' }}>
                        <CheckBox
                            title='User'
                            textStyle={ApplicationStyles.h6}
                            containerStyle={{ backgroundColor: 'transparent', borderWidth: 0 }}
                            size={totalSize(2)}
                            checkedIcon='dot-circle-o'
                            uncheckedIcon='circle-o'
                            checkedColor={colors.appColor1}
                            checked={this.state.checked}
                            onPress={this.onUserCheck}
                        />
                        <CheckBox
                            title='Politician'
                            textStyle={ApplicationStyles.h6}
                            containerStyle={{ backgroundColor: 'transparent', borderWidth: 0 }}
                            size={totalSize(2)}
                            checkedIcon='dot-circle-o'
                            uncheckedIcon='circle-o'
                            checkedColor={colors.appColor1}
                            checked={!this.state.checked}
                            onPress={this.onPoliticianCheck}
                        />
                    </View> */}
                    <View style={{marginTop : height(3)}}></View>
                    <TouchableOpacity onPress={()=>{this.props.navigation.navigate('forgotPassword')}} style={{ marginTop: height(2.5), alignItems: 'center' }}>
                        <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5 }]}>Forgot your password?</Text>
                    </TouchableOpacity>
                    {this.state.email != '' && this.state.password.length != '' ?
                    <TouchableOpacity onPress={()=>{this.Login()}} style={[ApplicationStyles.buttonColord, { marginVertical: height(5) }]}>
                            {this.state.loader == false ? 
                            <Text style={ApplicationStyles.buttonText}>Sign In</Text>
                            :
                                <ActivityIndicator size='small' color='white'></ActivityIndicator>
                            }                   
                             </TouchableOpacity>
                    :
                    <TouchableOpacity disabled={true} style={[ApplicationStyles.buttonColord, {opacity : .5, marginVertical : height(5)}]}>
                    <Text style={ApplicationStyles.buttonText}>Log In</Text>
                </TouchableOpacity>
                    }
                </ScrollView>
                <Modal
                    onBackdropPress={this.togglePasswordSendModal}
                    isVisible={this.state.isPasswordSendModalVisible}
                >
                    <View style={{ backgroundColor: '#FFFF', borderRadius: 10, marginHorizontal: width(10) }}>
                        <View style={{ alignItems: 'center', marginVertical: height(5) }}>
                            <Image source={images.sent_icon} resizeMode={"contain"} style={{ height: totalSize(10), width: totalSize(10) }} />
                        </View>
                        <View style={[ApplicationStyles.compContainer, { alignItems: 'center', marginBottom: height(5) }]}>
                            <Text style={[ApplicationStyles.h6, { textAlign: 'center' }]}>Password has been sent to</Text>
                            <Text style={[ApplicationStyles.h5, { textAlign: 'center', color: colors.appColor1, fontFamily: family.appTextMedium }]}>jhonwick003@gmail.com</Text>
                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
    validateEmail = Cnic => {
        var re = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,9})$/;
        return re.test(Cnic);
      };
}

export default Login;

const styles = StyleSheet.create({
    inputField: {
        // marginTop: height(1),
    },
    card: {
        marginHorizontal: width(7.5),
        backgroundColor: colors.appColor1,
        borderRadius: 10,
        marginVertical: height(2.5)
    },
    cardText: {
        color: '#FFFFFF'
    }
})