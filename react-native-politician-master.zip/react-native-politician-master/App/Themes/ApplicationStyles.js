import { StyleSheet } from 'react-native'
import { totalSize, height, width } from 'react-native-dimension'
import colors from './Colors'
import family from './Fonts'
export default StyleSheet.create({
  bgImageContainer: {
    flex: 1,
    height: null,
    width: null
  },
  mainContainer: {
    flex: 1,
    backgroundColor: colors.appBgColor1
  },
  h1: {
    fontSize: totalSize(5),
    color: colors.appTextColor3,
    fontFamily: family.appTextBold
  },
  h2: {
    fontSize: totalSize(4),
    color: colors.appTextColor3,
    fontFamily: family.appTextMedium
  },
  h3: {
    fontSize: totalSize(3),
    color: colors.appTextColor3,
    fontFamily: family.appTextMedium
  },
  h4: {
    fontSize: totalSize(2),
    color: colors.appTextColor3,
    fontFamily: family.appTextMedium
  },
  h5: {
    fontSize: totalSize(1.5),
    color: colors.appTextColor3,
    fontFamily: family.appTextRegular
  },
  h6: {
    fontSize: totalSize(1.25),
    color: colors.appTextColor3,
    fontFamily: family.appTextRegular
  },
  inputContainerUnderLined: {
    marginHorizontal: width(7.5),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: colors.appColor1,
    borderRadius: 5
  },
  inputContainerBorderd: {
    marginHorizontal: width(7.5),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    borderWidth: 0.5,
    borderColor: colors.appColor1,
    borderRadius: 5
  },
  inputContainerColored: {
    marginHorizontal: width(7.5),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    backgroundColor: colors.appColor1,
    borderRadius: 5
  },
  inputField: {
    height: height(7),
    width: width(80),
    fontSize: totalSize(1.5)
  },
  inputFieldBorderd: {
    marginHorizontal: width(7.5),
    height: height(7),
    borderWidth: 0.5,
    borderColor: colors.appColor1,
    fontSize: totalSize(1.75),
    fontFamily: family.appTextRegular,
    borderRadius: 5
  },
  inputFieldColored: {
    marginHorizontal: width(7.5),
    height: height(7),
    fontSize: totalSize(1.75),
    elevation: 5,
    backgroundColor: colors.appColor1,
    borderRadius: 5
  },
  inputFieldUnderlined: {
    marginHorizontal: width(7.5),
    height: height(7),
    fontSize: totalSize(1.25),
    borderBottomWidth: 1,
    borderBottomColor: colors.appColor1
  },
  buttonBorderd: {
    marginHorizontal: width(7.5),
    height: height(7),
    borderRadius: 2.5,
    borderWidth: 1,
    borderColor: colors.appColor1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  buttonColord: {
    marginHorizontal: width(7.5),
    height: height(7),
    borderRadius: 100,
    backgroundColor: colors.appColor1,
    elevation: 5,
    alignItems: 'center',
    justifyContent: 'center'
  },
  SocialButtonColord: {
    height: height(8),
    marginHorizontal: width(5),
    borderRadius: 2.5,
    backgroundColor: colors.facebook,
    //  alignItems: 'center',
    //  justifyContent: 'center'
  },
  buttonText: {
    fontSize: totalSize(1.5),
    color: '#FFFFFF',
    fontFamily: family.appTextMedium
  },
  compContainer: {
    marginHorizontal: width(7.5),
    marginVertical: height(2.5)
  },
  rowCompContainer: {
    marginHorizontal: width(7.5),
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: height(2.5)
  },
  headerTitleStyles: {
    fontSize: totalSize(1.75),
    color: colors.appTextColor3,
    fontFamily: family.appTextMedium
  },
  headingUnderlineStyle: {
    width: width(40),
    borderBottomWidth: 0.5,
    borderBottomColor: colors.appTextColor6,
    marginTop: 2.5
  },
})