// leave off @2x/@3x
const images = {
    jaguar_logo: require('../Assets/Logos/Jaguar_logo.png'),
    visa_logo: require('../Assets/Logos/visa-logo.png'),
    sent_icon: require('../Assets/Icons/sent_icon.png'),
    done_icon: require('../Assets/Icons/done_icon.png'),
    menu_burger_icon: require('../Assets/Icons/menu_burger_icon.png'),
    filter_icon: require('../Assets/Icons/filter_icon.png'),
    p1: require('../Assets/Images/p1.jpg'),
    p2: require('../Assets/Images/p2.jpg'),
    p3: require('../Assets/Images/p3.jpg'),
    u1: require('../Assets/Images/u1.jpg'),
    u2: require('../Assets/Images/u2.jpg'),
    f1: require('../Assets/Images/f1.jpg'),
    f2: require('../Assets/Images/f2.jpg'),
    bill: require('../Assets/Images/bill.png')
}

export default images;
