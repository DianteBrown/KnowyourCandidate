import React, { Component } from 'react';
import { View, Text, ScrollView, Image, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { Icon } from 'react-native-elements';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize, height, width } from 'react-native-dimension';

class ProfileFeedsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={this.props.data}
                renderItem={({ item, index }) =>
                    <TouchableOpacity onPress={this.props.onPress} activeOpacity={1} style={[styles.feedContainer, { marginLeft: index === 0 ? width(7.5) : 0 }]} >
                        <View>
                            <Image source={item != undefined && item != null && item != "" ? {uri : item} : images.p1} style={index % 2 ? [styles.feedImageStyle, { height: height(15) }] : styles.feedImageStyle} />
                            <View style={{ position: 'absolute', bottom: 7.5, right: 7.5 }}>
                                {
                                    item.liked ?
                                        <Icon name="ios-heart" type="ionicon" color="#FFFF" size={totalSize(2.5)} />
                                        :
                                        <Icon name="ios-heart-empty" type="ionicon" color="#FFFF" size={totalSize(2.5)} />
                                }
                            </View>
                        </View>
                        <View style={{ marginTop: 5 }}>
                            <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextMedium }]}>{item.title}</Text>
                            <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight }]}>{item.description}</Text>
                        </View>
                    </TouchableOpacity>
                }
            />
        );
    }
}

export default ProfileFeedsList;

const styles = StyleSheet.create({
    feedContainer: {
        // height: height(20),
        // borderRadius: 10,
        width: width(42.5),
        marginRight: width(2.5),
    },
    feedImageStyle: {
        height: height(25),
        borderRadius: 5,
        width: null
        //width: width(42.5)
    }
})