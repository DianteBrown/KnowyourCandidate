import React, { Component } from 'react';
import { View, Text, ScrollView, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize, height, width } from 'react-native-dimension';

class BillsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ marginVertical: height(2.5), flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginHorizontal: width(5), flexWrap: 'wrap' }}>
                    {
                        this.props.bills.map((item, key) => {
                            return (
                                <TouchableOpacity activeOpacity={1} onPress={()=>{this.props.navigate('billDetail',{data : item})}} style={styles.billContainer}>
                                    <View>
                                        <Image source={item != undefined && item != null && item != "" ? {uri : item} : images.p1} style={styles.billImageStyle} />
                                        <View style={{ position: 'absolute', bottom: 7.5, right: 7.5 }}>
                                            {
                                                item.liked ?
                                                    <Icon name="ios-heart" type="ionicon" color="#FFFF" size={totalSize(2.5)} />
                                                    :
                                                    <Icon name="ios-heart-empty" type="ionicon" color="#FFFF" size={totalSize(2.5)} />
                                            }
                                        </View>
                                    </View>
                                    <View style={{ marginTop: 5 }}>
                                        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>{item.title}</Text>
                                        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight }]}>{item.description}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                </View>
            </ScrollView>
        );
    }
}

export default BillsList;

const styles = StyleSheet.create({
    billContainer: {
        // height: height(20),
        //  borderRadius: 10,
        width: width(42.5),
        marginBottom: height(2.5)
    },
    billImageStyle: {
        height: height(25),
        borderRadius: 5,
        width: null
        //width: width(42.5)
    }
})