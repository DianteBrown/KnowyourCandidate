import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { totalSize } from 'react-native-dimension';
import colors from '../Themes/Colors';
import { Icon } from 'react-native-elements';

class ActiveTabDot extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <View style={{ position: 'absolute', top: totalSize(3) }}>
                <Icon name="primitive-dot" type="octicon" color={colors.appColor1} size={totalSize(1.5)} />
            </View>
        );
    }
}

export default ActiveTabDot;
