import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { Icon } from 'react-native-elements';
import { totalSize } from 'react-native-dimension';

class ImageIcon extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <Icon onPress={this.props.onPress} name="image" type="evilicon" size={totalSize(5)} color="#FFFF" />
        );
    }
}

export default ImageIcon;
