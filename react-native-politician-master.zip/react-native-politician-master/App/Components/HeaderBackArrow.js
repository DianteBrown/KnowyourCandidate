import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { Icon } from 'react-native-elements';
import { totalSize, width } from 'react-native-dimension';
import colors from '../Themes/Colors';

class HeaderBackArrow extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <Icon name="ios-arrow-back" type="ionicon" reverse reverseColor={colors.appTextColor3} color={'transparent'} size={totalSize(2.5)} iconStyle={{  }} onPress={this.props.onPress} />
        );
    }
}

export default HeaderBackArrow;
