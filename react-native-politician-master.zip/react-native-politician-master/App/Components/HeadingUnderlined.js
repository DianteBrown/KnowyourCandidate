import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ApplicationStyles from '../Themes/ApplicationStyles';
import { width, height, totalSize } from 'react-native-dimension';
import colors from '../Themes/Colors';
import family from '../Themes/Fonts';

class HeadingUnderlined extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <View style={[ApplicationStyles.compContainer, {  }]}>
                <View>
                    <Text style={[ApplicationStyles.h4, styles.heading]}>{this.props.heading} <Text style={[ApplicationStyles.h6, styles.subHeading]}>{this.props.subHeading}</Text></Text>
                    <View style={styles.line}></View>
                </View>
            </View>
        );
    }
}

export default HeadingUnderlined;

const styles = StyleSheet.create({
    line: {
        width: width(40),
        borderBottomWidth: 0.5,
        borderBottomColor: colors.appTextColor6,
        marginTop: 2.5
    },
    heading: {
        fontSize: totalSize(1.75)
    },
    subHeading: {
        fontSize: totalSize(1),
        color: colors.appTextColor5,
        fontFamily: family.appTextRegular
    },
})