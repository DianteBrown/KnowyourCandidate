import React, { Component } from 'react';
import { View, Text, ScrollView, Image, FlatList, TouchableOpacity } from 'react-native';
import { width, height, totalSize } from 'react-native-dimension';
import images from '../Themes/Images';
import family from '../Themes/Fonts';
import ApplicationStyles from '../Themes/ApplicationStyles';

class UsersListHorizontal extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={this.props.data}
                renderItem={({ item, index }) =>
                    <TouchableOpacity activeOpacity={1} onPress={()=>{this.props.navigate('viewUserProfile',{data : item})}} style={{ width: width(25), backgroundColor: '#FFFF', borderRadius: 5, elevation: 5, marginHorizontal: width(1.5), marginLeft: index === 0 ? width(5) : null, marginVertical: height(1.5) }}>
                        <Image source={images.u1} style={{ height: height(12.5), width: null, borderTopLeftRadius: 5, borderTopRightRadius: 5 }} />
                        <View style={{ marginVertical: height(1), marginHorizontal: width(2.5) }}>
        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextMedium }]}>{item.user_name}</Text>
                        </View>
                    </TouchableOpacity>
                }
            />
        );
    }
}

export default UsersListHorizontal;
