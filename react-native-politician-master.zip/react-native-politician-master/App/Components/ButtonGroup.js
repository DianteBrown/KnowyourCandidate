import React, { Component } from 'react';
import { View, Text, ScrollView, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize, height, width } from 'react-native-dimension';
import colors from '../Themes/Colors';

class ButtonGroup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedIndex: 0
        };
    }
    updateIndex = (index) => {
        this.setState({ selectedIndex: index })
    }
    render() {
        return (
            <View style={ApplicationStyles.rowCompContainer}>
                {
                    this.props.buttons.map((item, key) => {
                        return (
                            <TouchableOpacity activeOpacity={1} style={key === this.state.selectedIndex ? styles.typeButtonOn : styles.typeButtonOff}
                                onPress={() => {this.updateIndex(key);this.props.selected(item)}}
                            >
                                <Text style={[ApplicationStyles.h6, styles.typeButtonText]}>{item}</Text>
                            </TouchableOpacity>
                        )
                    })
                }
            </View>
        );
    }
}

export default ButtonGroup;

const styles = StyleSheet.create({
    typeButtonOn: {
        backgroundColor: colors.appColor1,
        borderRadius: 25,
        elevation: 5,
    },
    typeButtonOff: {
        backgroundColor: colors.appTextColor5,
        borderRadius: 25,
        //  elevation: 5,
    },
    typeButtonText: {
        fontSize: totalSize(1),
        color: '#FFFFFF',
        marginHorizontal: 20,
        marginVertical: 2.5
    },
})