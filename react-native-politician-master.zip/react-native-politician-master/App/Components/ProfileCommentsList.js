import React, { Component } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize, height, width } from 'react-native-dimension';
import colors from '../Themes/Colors';
import StarRating from 'react-native-star-rating';

class ProfileCommentsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                data={this.props.data}
                renderItem={({ item, index }) =>
                    <View>
                        <View style={styles.feedContainer}>
                            <View style={{ flexDirection: 'row', marginVertical: height(2.5), alignItems: 'center' }}>
                                <View style={{ flex: 3 }}>
                                    <View style={{ marginHorizontal: width(2.5) }}>
                                        <Image source={item.image} style={{ height: height(12.5), width: null, borderRadius: 5 }} />
                                    </View>
                                </View>
                                <View style={{ flex: 7, backgroundColor: 'transparent' }}>
                                    <View style={{ marginHorizontal: width(2.5) }}>
                                        <View style={{ marginHorizontal: 0, flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                                            <Text style={[ApplicationStyles.h4, { fontFamily: family.appTextMedium, fontSize: totalSize(1.4) }]}>{item.title}</Text>
                                            <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6, fontSize: totalSize(1) }]}>10/10/2019</Text>
                                        </View>
                                        <View style={{ marginVertical: 5 }}>
                                            <Text style={[ApplicationStyles.h6, { fontSize: totalSize(1), fontFamily: family.appTextLight }]}>{item.detail}</Text>
                                        </View>
                                    </View>
                                </View>
                            </View>
                        </View>
                        <FlatList
                            data={item.comments}
                            renderItem={({ item, index }) =>
                                <View style={styles.reviewContainer}>
                                    <View style={{ flexDirection: 'row', alignSelf: 'flex-start', marginVertical: height(2.5) }}>
                                        <View style={{ flex: 2 }}>
                                            <Image source={item.image} style={{ height: totalSize(5), width: totalSize(5), borderWidth: 1, borderColor: colors.steel, borderRadius: 100, alignSelf: 'center' }} />
                                        </View>
                                        <View style={{ flex: 8, backgroundColor: 'transparent' }}>
                                            <View style={{ marginHorizontal: width(2.5) }}>
                                                <View style={{ marginHorizontal: 0, flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                                                    <Text style={[ApplicationStyles.h4, { fontFamily: family.appTextMedium, fontSize: totalSize(1.4) }]}>{item.name}</Text>
                                                    <Text style={[ApplicationStyles.h6, { color: colors.appTextColor6, fontSize: totalSize(1) }]}>10/10/2019</Text>
                                                </View>
                                                <View style={{ marginVertical: 5 }}>
                                                    <Text style={[ApplicationStyles.h6, { fontSize: totalSize(1), fontFamily: family.appTextLight }]}>{item.review}</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            }
                        />
                    </View>

                }
            />
        );
    }
}

export default ProfileCommentsList;

const styles = StyleSheet.create({
    title: {
        fontSize: totalSize(1.75)
    },
    subTitle: {
        fontFamily: family.appTextMedium
    },
    heading: {
        fontFamily: family.appTextBold
    },
    topDetail: {
        fontFamily: family.appTextLight
    },
    photoStyle: {
        height: totalSize(10),
        width: totalSize(10),
        borderRadius: 5,
        marginVertical: height(2.5),
        marginRight: width(2.5)
    },
    TitleUnderline: {
        width: width(40),
        borderBottomWidth: 0.5,
        borderBottomColor: colors.appTextColor6,
        marginTop: 2.5
    },
    bottomDetail: {
        fontFamily: family.appTextLight
    },
    feedContainer: {
        marginHorizontal: width(7.5),
        backgroundColor: '#FFFF',
        borderRadius: 5,
        elevation: 5,
        marginVertical: height(1),
        //flexDirection: 'row',
        //alignItems: 'center'
    },
    reviewContainer: {
        marginRight: width(2.5),
        marginLeft: width(15),
        backgroundColor: '#FFFF',
        borderRadius: 5,
        elevation: 5,
        marginVertical: height(1),
        //flexDirection: 'row',
        //alignItems: 'center'
    },
    ratingAreaContainer: {
        marginTop: 0
    }
})