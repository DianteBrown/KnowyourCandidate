import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { Icon } from 'react-native-elements';
import { totalSize } from 'react-native-dimension';
import colors from '../Themes/Colors';

class HeaderSearchIcon extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <Icon name="ios-search" type="ionicon" reverse reverseColor={colors.appTextColor3} size={totalSize(2.5)} color={'transparent'} onPress={this.props.onPress} />
        );
    }
}

export default HeaderSearchIcon;
