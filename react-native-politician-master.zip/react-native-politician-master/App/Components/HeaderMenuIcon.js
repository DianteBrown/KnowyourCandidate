import React, { Component } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import images from '../Themes/Images';
import { totalSize, width, height } from 'react-native-dimension';

class HeaderMenuIcon extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <TouchableOpacity activeOpacity={1} style={{ marginLeft: width(5) }} onPress={this.props.onPress}>
                <Image source={images.menu_burger_icon} resizeMode={"contain"} style={{ height: totalSize(1.5), width: totalSize(2.5) }} />
            </TouchableOpacity>
        );
    }
}

export default HeaderMenuIcon;
