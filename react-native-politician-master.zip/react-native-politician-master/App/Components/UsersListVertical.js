import React, { Component } from 'react';
import { View, Text, ScrollView, Image, FlatList } from 'react-native';
import { width, height, totalSize } from 'react-native-dimension';
import images from '../Themes/Images';
import family from '../Themes/Fonts';
import ApplicationStyles from '../Themes/ApplicationStyles';
import colors from '../Themes/Colors';
import { Icon } from 'react-native-elements';
import { TouchableOpacity } from 'react-native-gesture-handler';

class UsersListVertical extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                showsVerticalScrollIndicator={false}
                data={this.props.data}
                renderItem={({ item, index }) =>
                    <TouchableOpacity onPress={()=>{ if(item.role == 'User') this.props.navigate('viewUserProfile',{data : item})}} style={{ marginHorizontal: width(7.5), borderBottomWidth: 0.5, borderBottomColor: colors.steel }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: height(2.5), justifyContent: 'space-between' }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', }}>
                                <Image source={images.u1} style={{ height: totalSize(5), width: totalSize(5), borderRadius: 100 }} />
        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextMedium, marginHorizontal: width(2.5) }]}>{item.full_name}</Text>
                            </View>
                            <View>
                                <Icon name="ios-arrow-forward" type="ionicon" size={totalSize(2)} color={colors.appTextColor5} />
                            </View>
                        </View>

                    </TouchableOpacity>
                }
            />
        );
    }
}

export default UsersListVertical;
