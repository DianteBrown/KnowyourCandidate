import React, { Component } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize, height, width } from 'react-native-dimension';
import colors from '../Themes/Colors';

class ForumsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                data={this.props.forums}
                renderItem={({ item, index }) =>
                    <TouchableOpacity activeOpacity={1} onPress={()=>{this.props.navigate('forumDetail',{data : item})}} style={styles.forumContainer}>
                        <View style={styles.forumSubContainer}>
                            <View style={styles.titleContainer}>
                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextBold }]}>{item.title} ({item.total_comments} comments)</Text>
                                <Text style={[ApplicationStyles.h6, { color: colors.appTextColor5, fontSize: totalSize(1) }]}>View all</Text>
                            </View>
                            <View style={styles.detailContainer}>
                                <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight, fontSize: totalSize(1) }]}>{item.description}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                }
            />
        );
    }
}

export default ForumsList;

const styles = StyleSheet.create({
    forumContainer: {
        marginHorizontal: width(5),
        backgroundColor: '#FFFF',
        borderRadius: 10,
        elevation: 5,
        marginVertical: height(1.5)
    },
    forumSubContainer: {
        marginHorizontal: width(5),
        marginVertical: height(2.5)
    },
    titleContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    detailContainer: {
        marginVertical: height(1)
    }
})