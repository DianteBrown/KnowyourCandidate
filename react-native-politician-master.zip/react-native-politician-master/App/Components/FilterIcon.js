import React, { Component } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import images from '../Themes/Images';
import { totalSize, width } from 'react-native-dimension';

class FilterIcon extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <TouchableOpacity activeOpacity={1} style={{ marginRight: width(5) }} onPress={this.props.onPress}>
                <Image source={images.filter_icon} resizeMode={"contain"} style={{ height: totalSize(2.5), width: totalSize(2.5) }} />
            </TouchableOpacity>
        );
    }
}

export default FilterIcon;
