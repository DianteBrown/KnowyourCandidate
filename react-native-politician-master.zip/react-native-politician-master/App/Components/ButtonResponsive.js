import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import colors from '../Themes/Colors';
import ApplicationStyles from '../Themes/ApplicationStyles';
import { totalSize } from 'react-native-dimension';
import family from '../Themes/Fonts';

class ButtonResponsive extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <TouchableOpacity onPress={this.props.onPress} style={{ backgroundColor: colors.appColor1, borderRadius: 100 }}>
                <Text style={[ApplicationStyles.h6, { color: '#FFFF', marginHorizontal: 10, marginVertical: 5, fontFamily: family.appTextMedium }]}>{this.props.buttonText}</Text>
            </TouchableOpacity>
        );
    }
}

export default ButtonResponsive;
