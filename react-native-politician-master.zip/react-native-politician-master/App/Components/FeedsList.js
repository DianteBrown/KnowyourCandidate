import React, { Component } from 'react';
import { View, Text, ScrollView, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Icon } from 'react-native-elements';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize, height, width } from 'react-native-dimension';

class FeedsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ marginVertical: height(2.5), flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginHorizontal: width(5), flexWrap: 'wrap' }}>
                    {
                        this.props.feeds.map((item, key) => {
                            return (
                                <TouchableOpacity onPress={()=>{this.props.navigate('feedDetail',{data : item})}} activeOpacity={1} style={styles.feedContainer} >
                                    <View>
                                        <Image source={item != undefined && item != null && item != "" ? {uri : item} : images.p1} style={key % 2 ? [styles.feedImageStyle, { height: height(15) }] : styles.feedImageStyle} />
                                        <View style={{ position: 'absolute', bottom: 7.5, right: 7.5 }}>
                                            {
                                                item.liked ?
                                                    <Icon name="ios-heart" type="ionicon" color="#FFFF" size={totalSize(2.5)} />
                                                    :
                                                    <Icon name="ios-heart-empty" type="ionicon" color="#FFFF" size={totalSize(2.5)} />
                                            }
                                        </View>
                                    </View>
                                    <View style={{ marginTop: 5 }}>
                                        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextMedium }]}>{item.title}</Text>
                                        <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextLight }]}>{item.description}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    }
                </View>
            </ScrollView >
        );
    }
}

export default FeedsList;

const styles = StyleSheet.create({
    feedContainer: {
        // height: height(20),
        //  borderRadius: 10,
        width: width(42.5),
        marginBottom: height(2.5)
    },
    feedImageStyle: {
        height: height(25),
        borderRadius: 5,
        width: null
        //width: width(42.5)
    }
})