import React, { Component } from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import ApplicationStyles from '../Themes/ApplicationStyles';
import { height, width, totalSize } from 'react-native-dimension';
import { Icon } from 'react-native-elements';
import colors from '../Themes/Colors';

class FilterItemsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                data={this.props.data}
                renderItem={({ item, index }) =>
                    <TouchableOpacity activeOpacity={1} onPress={this.props.onPress} style={[ApplicationStyles.rowCompContainer, { marginTop: 0, marginBottom: height(1.5) }]}>
                        <Text style={ApplicationStyles.h6}>{item.name}</Text>
                        <View style={{ marginHorizontal: width(5) }}>
                            {
                                item.selected ?
                                    <Icon name="ios-radio-button-on" type="ionicon" size={totalSize(1.75)} color={colors.appColor1} />
                                    :
                                    <Icon name="ios-radio-button-off" type="ionicon" size={totalSize(1.75)} color={colors.appTextColor1} />
                            }
                        </View>
                    </TouchableOpacity>
                }
            />
        );
    }
}

export default FilterItemsList;
