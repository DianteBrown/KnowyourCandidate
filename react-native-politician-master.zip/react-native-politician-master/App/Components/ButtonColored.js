import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import ApplicationStyles from '../Themes/ApplicationStyles';

class ButtonColored extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <TouchableOpacity activeOpacity={1} onPress={this.props.onPress} style={ApplicationStyles.buttonColord}>
                <Text style={ApplicationStyles.buttonText}>{this.props.buttonText}</Text>
            </TouchableOpacity>
        );
    }
}

export default ButtonColored;
