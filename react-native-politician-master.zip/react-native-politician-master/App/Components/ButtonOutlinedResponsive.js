import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import colors from '../Themes/Colors';
import ApplicationStyles from '../Themes/ApplicationStyles';
import { totalSize } from 'react-native-dimension';

class ButtonOutlinedResponsive extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <TouchableOpacity onPress={this.props.onPress} style={{ borderRadius: 100, borderWidth: 1, borderColor: colors.appColor1 }}>
                <Text style={[ApplicationStyles.h6, { color: colors.appColor1, marginHorizontal: 10, marginVertical: 5 }]}>{this.props.buttonText}</Text>
            </TouchableOpacity>
        );
    }
}

export default ButtonOutlinedResponsive;
