import React, { Component } from 'react';
import { View, Text } from 'react-native';
import ApplicationStyles from '../Themes/ApplicationStyles';
import family from '../Themes/Fonts';
import { totalSize } from 'react-native-dimension';

class Heading extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <View>
                <Text style={[ApplicationStyles.h4, { fontSize: totalSize(1.75) }]}>{this.props.heading}</Text>
                <View style={ApplicationStyles.headingUnderlineStyle}></View>
            </View>
        );
    }
}

export default Heading;
