import React, { Component } from 'react';
import { View, Text, ScrollView, Image, FlatList, TouchableOpacity } from 'react-native';
import { width, height, totalSize } from 'react-native-dimension';
import images from '../Themes/Images';
import family from '../Themes/Fonts';
import ApplicationStyles from '../Themes/ApplicationStyles';
import { Icon } from 'react-native-elements';
import colors from '../Themes/Colors';
class PoliticianListHorizontal extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={this.props.data}
                renderItem={({ item, index }) =>
                    <TouchableOpacity activeOpacity={1} onPress={this.props.onPress} style={{ width: width(25), backgroundColor: '#FFFF', borderRadius: 5, elevation: 5, marginHorizontal: width(1.5), marginLeft: index === 0 ? width(5) : null, marginVertical: height(1.5) }}>
                        <Image source={images.p1} style={{ height: height(12.5), width: null, borderTopLeftRadius: 5, borderTopRightRadius: 5 }} />
                        <View style={{ marginVertical: height(1), marginHorizontal: width(2.5) }}>
                            <Text style={[ApplicationStyles.h6, { fontFamily: family.appTextMedium }]}>William Jim</Text>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Icon name="star" type="font-awesome" size={totalSize(1.25)} color={colors.appColor1} />
                                <Text style={[ApplicationStyles.h6, { fontSize: totalSize(1), color: colors.appTextColor4, marginLeft: 5 }]}>4.3</Text>
                            </View>
                        </View>
                    </TouchableOpacity>
                }
            />
        );
    }
}

export default PoliticianListHorizontal;
