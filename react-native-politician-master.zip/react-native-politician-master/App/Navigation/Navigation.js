import React, { Component } from 'react';
import { View, AsyncStorage } from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation'
import { createStackNavigator } from 'react-navigation-stack'
import { createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation-tabs'
import Splash from '../Containers/IntroFlow/splash'
import Donate from '../Containers/IntroFlow/donate'
import DonatePayment from '../Containers/IntroFlow/donatePayment'
import Signup from '../Containers/AuthFlow/signup'
import Login from '../Containers/AuthFlow/login'
import SignupPolitical from '../Containers/AuthFlow/signupPolitical'
import Home from '../Containers/MainFlow/Home/home'
import colors from '../Themes/Colors'
import HeaderBackArrow from '../Components/HeaderBackArrow';
import UserProfile from '../Containers/MainFlow/Profile/userProfile';
import PoliticalProfile from '../Containers/MainFlow/Profile/politicalProfile';
import Feeds from '../Containers/MainFlow/Feeds/feeds';
import Forum from '../Containers/MainFlow/Forum/forum';
import Bills from '../Containers/MainFlow/Bills/bills';
import { Icon } from 'react-native-elements';
import { totalSize, height, width } from 'react-native-dimension';
import Notifications from '../Containers/MainFlow/Notifications/notifications';
import ActiveTabDot from '../Components/ActiveTabDot';
import ApplicationStyles from '../Themes/ApplicationStyles';
import HeaderMenuIcon from '../Components/HeaderMenuIcon';
import Filter from '../Containers/MainFlow/Filter/filter';
import HeaderCloseIcon from '../Components/HeaderCloseIcon';
import ForumDetail from '../Containers/MainFlow/Forum/forumDetail';
import FeedDetail from '../Containers/MainFlow/Feeds/feedDetail';
import billDetail from '../Containers/MainFlow/Bills/billDetail';
import FavoriteFeeds from '../Containers/MainFlow/Feeds/favoriteFeeds';
import YourComments from '../Containers/MainFlow/Forum/yourComments';
import EditUserProfile from '../Containers/MainFlow/Profile/editUserProfile';
import EditPoliticalProfile from '../Containers/MainFlow/Profile/editPoliticalProfile';
import Gallery from '../Containers/MainFlow/Profile/gallery';
import Search from '../Containers/MainFlow/Search/search';
import FilterForum from '../Containers/MainFlow/Filter/filterForum';
import CalendarView from '../Containers/MainFlow/Calendar/calendarView'
import ViewPoliticalProfile from '../Containers/MainFlow/Profile/viewPoliticalProfile';
import ViewUserProfile from '../Containers/MainFlow/Profile/viewUserProfile';
import ForgotPassword from '../Containers/AuthFlow/forgotPassword';
const IntroStack = createStackNavigator({
    splash: {
        screen: Splash,
        navigationOptions: {
            header: null
        }
    },
    donate: {
        screen: Donate,
        navigationOptions: {
            header: null
        }
    },
    donatePayment: {
        screen: DonatePayment,
        navigationOptions: ({ navigation }) => {
            return {
                headerStyle: { backgroundColor: colors.appHeaderBgColor, elevation: 0 },
                headerLeft: (<HeaderBackArrow onPress={() => navigation.goBack()} />)
            }
        }
    }
})

const AuthStack = createStackNavigator({
    signup: {
        screen: Signup
    },
    login: {
        screen: Login
    },
    signupPolitical: {
        screen: SignupPolitical
    },
    forgotPassword : {
        screen : ForgotPassword
    }
},
    {
        initialRouteName: 'signup',
        defaultNavigationOptions: ({ navigation }) => {
            return {
                header: null
            }
        }
    }
)

const UserProfileStack = createStackNavigator({
    userProfile: {
        screen: UserProfile
    },
    editUserProfile: {
        screen: EditUserProfile
    },
    favoriteFeeds: {
        screen: FavoriteFeeds
    },
    yourComments: {
        screen: YourComments
    },
    gallery: {
        screen: Gallery
    }
})

const PoliticalProfileStack = createStackNavigator({
    politicalProfile: {
        screen: PoliticalProfile,
    },
    editPoliticalProfile: {
        screen: EditPoliticalProfile,
    },
    gallery: {
        screen: Gallery
    }
})

const FeedStack = createStackNavigator({
    feed: {
        screen: Feeds
    },
    feedDetail: {
        screen: FeedDetail
    }
})

const ForumStack = createStackNavigator({
    forum: {
        screen: Forum
    },
    forumDetail: {
        screen: ForumDetail
    }
})

const BillStack = createStackNavigator({
    bills: {
        screen: Bills
    },
    billDetail: {
        screen: billDetail
    }
})

const CalendarStack = createStackNavigator({
    calendarView: {
        screen: CalendarView
    }
})

const NotificationsStack = createStackNavigator({
    forum: {
        screen: Notifications
    }
})
const SearchStack = createStackNavigator({
    search: {
        screen: Search
    },
    viewPoliticalProfile: {
        screen: ViewPoliticalProfile
    },
    viewUserProfile: {
        screen: ViewUserProfile
    }
})
const TabIconSize = totalSize(2)

let UserType = async () => {
    const UserType = await AsyncStorage.getItem('UserType')
    return UserType
}

const UserMainTab = createMaterialTopTabNavigator({
    Search: {
        screen: SearchStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center', backgroundColor: 'transparent' }}>
                    <Icon name="md-search" type="ionicon" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Feeds: {
        screen: FeedStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="news" type="entypo" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },


    Forum: {
        screen: ForumStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="comment-text-multiple-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Bills: {
        screen: BillStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="file-document-box-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    calendar: {
        screen: CalendarStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="calendar-month-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    profile: {
        screen: UserProfileStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center', backgroundColor: 'transparent' }}>
                    <Icon name="account-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Notifications: {
        screen: NotificationsStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="bell-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    }
},
    {
        tabBarPosition: 'bottom',
        tabBarOptions: {
            showIcon: true,
            indicatorStyle: { backgroundColor: '#FFFF' },
            showLabel: false,
            activeTintColor: colors.appColor1,
            inactiveTintColor: 'grey',
            style: { borderTopWidth: 0, height: height(10), backgroundColor: '#FFFF', borderTopRightRadius: 15, borderTopLeftRadius: 25, elevation: 10 }
        }
    }
)

const PoliticianMainTab = createMaterialTopTabNavigator({
    Search: {
        screen: SearchStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center', backgroundColor: 'transparent' }}>
                    <Icon name="md-search" type="ionicon" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Feeds: {
        screen: FeedStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="news" type="entypo" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Forum: {
        screen: ForumStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="comment-text-multiple-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Bills: {
        screen: BillStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="file-document-box-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    calendar: {
        screen: CalendarStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="calendar-month-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    profile: {
        screen: PoliticalProfileStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center', backgroundColor: 'transparent' }}>
                    <Icon name="account-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    },
    Notifications: {
        screen: NotificationsStack,
        navigationOptions: {
            tabBarIcon: ({ tintColor, focused }) => (
                <View style={{ alignItems: 'center' }}>
                    <Icon name="bell-outline" type="material-community" color={tintColor} size={TabIconSize} />
                    {
                        focused ?
                            <ActiveTabDot />
                            :
                            null
                    }
                </View>
            )
        }
    }
},
    {
        tabBarPosition: 'bottom',
        tabBarOptions: {
            showIcon: true,
            indicatorStyle: { backgroundColor: '#FFFF' },
            showLabel: false,
            activeTintColor: colors.appColor1,
            inactiveTintColor: 'grey',
            style: { borderTopWidth: 0, height: height(10), backgroundColor: '#FFFF', borderTopRightRadius: 15, borderTopLeftRadius: 25, elevation: 10 }
        }
    }
)

const UserAppStack = createStackNavigator({
    mainTab: {
        screen: UserMainTab,
        navigationOptions: {
            header: null
        }
    },
    filter: {
        screen: Filter,
    },
    filterForum: {
        screen: FilterForum,
    },

})
const PoliticianAppStack = createStackNavigator({
    mainTab: {
        screen: PoliticianMainTab,
        navigationOptions: {
            header: null
        }
    },
    filter: {
        screen: Filter,
    },
    filterForum: {
        screen: FilterForum,
    },

})
const Switcher = createSwitchNavigator({
    Intro: IntroStack,
    Auth: AuthStack,
    UserApp: UserAppStack,
    PoliticianApp: PoliticianAppStack
},
    {
        initialRouteName: 'Intro'
    }
)

export default createAppContainer(Switcher)