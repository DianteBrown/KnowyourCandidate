import React, {Component} from 'react';
import {View, Alert,Text} from 'react-native';
import {_storeData,_retrieveData} from '../asyncStorage/AsyncFuncs';

export const Context = React.createContext("defualt Value");

export class MProvider extends Component{

  state = {
    user : '',
  }

  
  setUser=(user)=>{
    this.setState({
      user : user
    })
  }
  
  render(){
    return(
      <Context.Provider value={{
        state : this.state,
        setUser : this.setUser,
         }}>
        {this.props.children}
      </Context.Provider>
    )

  }
}