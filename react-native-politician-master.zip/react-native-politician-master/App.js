import React, { Component } from 'react';
import { View, Text, SafeAreaView } from 'react-native';
import Navigation from './App/Navigation/Navigation';
import {MProvider} from './App/contextApi';


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
      <SafeAreaView style={{ flex: 1 }}>
        <MProvider><Navigation /></MProvider>
      </SafeAreaView>
    );
  }
}

export default App;
